<!DOCTYPE html>
<html lang="zxx">
<!--<< Header Area >>-->

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Gramentheme">
    <meta name="description" content="Niotech - App Landing HTML Template">
    <!-- ======== Page title ============ -->
    <title>Niotech - App Landing HTML Template</title>
    <!--<< Favcion >>-->
    <!-- Favicon -->
    <link rel="shortcut icon" href="{{ asset('assets/images/favicon.png') }}">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{ asset('assets/css/all.min.css') }}">

    <!-- Animate -->
    <link rel="stylesheet" href="{{ asset('assets/css/animate.css') }}">

    <!-- Magnific Popup -->
    <link rel="stylesheet" href="{{ asset('assets/css/magnific-popup.css') }}">

    <!-- MeanMenu -->
    <link rel="stylesheet" href="{{ asset('assets/css/meanmenu.css') }}">

    <!-- Swiper -->
    <link rel="stylesheet" href="{{ asset('assets/css/swiper-bundle.min.css') }}">

    <!-- Nice Select -->
    <link rel="stylesheet" href="{{ asset('assets/css/nice-select.css') }}">

    <!-- Main CSS -->
    <link rel="stylesheet" href="{{ asset('assets/css/main.css') }}">
</head>

<body>

    <!-- Preloader Start -->
    <div id="preloader" class="preloader">
        <div class="animation-preloader">
            <div class="spinner">
            </div>
            <div class="txt-loading">
                <span data-text-preloader="N" class="letters-loading">
                    N
                </span>
                <span data-text-preloader="E" class="letters-loading">
                    i
                </span>
                <span data-text-preloader="O" class="letters-loading">
                    O
                </span>
                <span data-text-preloader="T" class="letters-loading">
                    T
                </span>
                <span data-text-preloader="E" class="letters-loading">
                    E
                </span>
                <span data-text-preloader="C" class="letters-loading">
                    C
                </span>
                <span data-text-preloader="H" class="letters-loading">
                    H
                </span>
            </div>
            <p class="text-center">Loading</p>
        </div>
        <div class="loader">
            <div class="row">
                <div class="col-3 loader-section section-left">
                    <div class="bg"></div>
                </div>
                <div class="col-3 loader-section section-left">
                    <div class="bg"></div>
                </div>
                <div class="col-3 loader-section section-right">
                    <div class="bg"></div>
                </div>
                <div class="col-3 loader-section section-right">
                    <div class="bg"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mouse Cursor Start -->
    <div class="mouse-cursor cursor-outer"></div>
    <div class="mouse-cursor cursor-inner"></div>

    <!-- Back To Top Start -->
    <button id="back-top" class="back-to-top">
        <i class="fa-solid fa-chevron-up"></i>
    </button>

    <!-- Offcanvas Area Start -->
    <div class="fix-area">
        <div class="offcanvas__info">
            <div class="offcanvas__wrapper">
                <div class="offcanvas__content">
                    <div class="offcanvas__top mb-5 d-flex justify-content-between align-items-center">
                        <div class="offcanvas__logo">
                            <a href="{{ route('home') }}">
                                <img src="assets/images/logo/logo2.svg" alt="logo-img">
                            </a>
                        </div>
                        <div class="offcanvas__close">
                            <button>
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <p class="text d-none d-xl-block">
                        Nullam dignissim, ante scelerisque the is euismod fermentum odio sem semper the is erat, a
                        feugiat leo urna eget eros. Duis Aenean a imperdiet risus.
                    </p>
                    <div class="mobile-menu fix mb-3"></div>
                    <div class="offcanvas__contact">
                        <h4>Contact Info</h4>
                        <ul>
                            <li class="d-flex align-items-center">
                                <div class="offcanvas__contact-icon">
                                    <i class="fal fa-map-marker-alt"></i>
                                </div>
                                <div class="offcanvas__contact-text">
                                    <a target="_blank" href="#">Main Street, Melbourne, Australia</a>
                                </div>
                            </li>
                            <li class="d-flex align-items-center">
                                <div class="offcanvas__contact-icon mr-15">
                                    <i class="fal fa-envelope"></i>
                                </div>
                                <div class="offcanvas__contact-text">
                                    <a href="mailto:info@example.com"><span
                                            class="mailto:info@example.com">info@example.com</span></a>
                                </div>
                            </li>
                            <li class="d-flex align-items-center">
                                <div class="offcanvas__contact-icon mr-15">
                                    <i class="fal fa-clock"></i>
                                </div>
                                <div class="offcanvas__contact-text">
                                    <a target="_blank" href="#">Mod-friday, 09am -05pm</a>
                                </div>
                            </li>
                            <li class="d-flex align-items-center">
                                <div class="offcanvas__contact-icon mr-15">
                                    <i class="far fa-phone"></i>
                                </div>
                                <div class="offcanvas__contact-text">
                                    <a href="tel:+11002345909">+11002345909</a>
                                </div>
                            </li>
                        </ul>
                        <div class="header-button mt-4">
                            <a href="contact.html" class="theme-btn text-center">
                                <span>Get A Quote<i class="fa-solid fa-arrow-right-long"></i></span>
                            </a>
                        </div>
                        <div class="social-icon d-flex align-items-center">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-youtube"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas__overlay"></div>

    <!-- Header Section Start -->
    <header class="header-section-1">
        <div id="header-sticky" class="header-1">
            <div class="container">
                <div class="mega-menu-wrapper">
                    <div class="header-main">
                        <div class="header-left">
                            <div class="logo">
                                <a href="{{ route('home') }}" class="header-logo">
                                    <img src="assets/images/logo/logo.svg" alt="logo-img">
                                </a>
                            </div>
                        </div>
                        <div class="header-middle">
                            <div class="mean__menu-wrapper">
                                <div class="main-menu">
                                    <nav id="mobile-menu">
                                        <ul>
                                            <li class="has-dropdown active menu-thumb">
                                                <a href="#">
                                                    Home
                                                    <i class="fas fa-angle-down"></i>
                                                </a>
                                                <ul class="submenu has-homemenu">
                                                    <li>
                                                        <div class="homemenu-items">
                                                            <div class="homemenu">
                                                                <div class="homemenu-thumb">
                                                                    <img src="assets/images/header/home-1.png"
                                                                        alt="img">
                                                                    <div class="demo-button">
                                                                        <a class="theme-btn" href="{{ route('home') }}">
                                                                            Multi Page
                                                                        </a>
                                                                        <a class="theme-btn" href="{{ route('one-page') }}">
                                                                            One Page
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="homemenu-content text-center">
                                                                    <h4 class="homemenu-title">
                                                                        Home 01
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="homemenu">
                                                                <div class="homemenu-thumb mb-15">
                                                                    <img src="assets/images/header/home-2.png"
                                                                        alt="img">
                                                                    <div class="demo-button">
                                                                        <a class="theme-btn" href="{{ route('home2') }}">
                                                                            Multi Page
                                                                        </a>
                                                                        <a class="theme-btn" href="{{ route('two-page') }}">
                                                                            One Page
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="homemenu-content text-center">
                                                                    <h4 class="homemenu-title">
                                                                        Home 02
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="homemenu">
                                                                <div class="homemenu-thumb mb-15">
                                                                    <img src="assets/images/header/home-3.png"
                                                                        alt="img">
                                                                    <div class="demo-button">
                                                                        <a class="theme-btn" href="{{ route('home3') }}">
                                                                            Multi Page
                                                                        </a>
                                                                        <a class="theme-btn" href="{{ route('three-page') }}">
                                                                            One Page
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="homemenu-content text-center">
                                                                    <h4 class="homemenu-title">
                                                                        Home 03
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="has-dropdown active d-xl-none">
                                                <a href="{{ route('home') }}" class="border-none">
                                                    Home
                                                    <i class="fa-regular fa-plus"></i>
                                                </a>
                                                <ul class="submenu">
                                                    <li><a href="{{ route('home') }}">Home 01</a></li>
                                                    <li><a href="{{ route('home2') }}">Home 02</a></li>
                                                    <li><a href="{{ route('home3') }}">Home 03</a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="{{ route('about') }}">About Us</a>
                                            </li>
                                            <li>
                                                <a href="services.html">
                                                    Services
                                                    <i class="fas fa-angle-down"></i>
                                                </a>
                                                <ul class="submenu">
                                                    <li><a href="services.html">Services</a></li>
                                                    <li><a href="service-details.html">Service Details</a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="pricing.html">
                                                    Pricing
                                                </a>
                                            </li>
                                            <li class="has-dropdown">
                                                <a href="#">
                                                    Pages
                                                    <i class="fas fa-angle-down"></i>
                                                </a>
                                                <ul class="submenu">
                                                    <li class="has-dropdown">
                                                        <a href="project1.html">
                                                            Project
                                                            <i class="fas fa-angle-down"></i>
                                                        </a>
                                                        <ul class="submenu">
                                                            <li><a href="project1.html">Project 01</a></li>
                                                            <li><a href="project2.html">Project 02</a></li>
                                                            <li><a href="project-details.html">Project Details</a></li>
                                                        </ul>
                                                    </li>
                                                    <li class="has-dropdown">
                                                        <a href="team.html">
                                                            Team
                                                            <i class="fas fa-angle-down"></i>
                                                        </a>
                                                        <ul class="submenu">
                                                            <li><a href="team.html">Team</a></li>
                                                            <li><a href="team-details.html">Team Details</a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li><a href="faq.html">Faq's</a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="blog.html">
                                                    Blogs
                                                    <i class="fas fa-angle-down"></i>
                                                </a>
                                                <ul class="submenu">
                                                    <li><a href="blog.html">Blog</a></li>
                                                    <li><a href="blog-standard.html">Blog Standard</a></li>
                                                    <li><a href="blog-left-sidebar.html">Blog Left Sidebar</a></li>
                                                    <li><a href="blog-details.html">Blog Details</a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="contact.html">Contact Us</a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                        <div class="header-right d-flex justify-content-end align-items-center">
                            <a href="#0" class="search-trigger search-icon"><i class="fal fa-search"></i></a>

                            <div class="header-button ms-4">
                                <a href="contact.html" class="theme-btn">
                                    <span>
                                        Get Started
                                        <i class="fa-solid fa-arrow-right-long"></i>
                                    </span>
                                </a>
                            </div>
                            <div class="header__hamburger d-block d-xl-none my-auto">
                                <div class="sidebar__toggle">
                                    <i class="fas fa-bars"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Search Area Start -->
    <div class="search-wrap">
        <div class="search-inner">
            <i class="fas fa-times search-close" id="search-close"></i>
            <div class="search-cell">
                <form method="get">
                    <div class="search-field-holder">
                        <input type="search" class="main-search-input" placeholder="Search...">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Intro Section S T A R T -->
    <section class="intro-section">
        <div class="intro-container-wrapper style1">
            <div class="container">
                <div class="intro-wrapper style1 fix">
                    <div class="shape1"><img src="assets/images/shape/introShape1_1.png" alt="shape"></div>
                    <div class="shape2"><img src="assets/images/shape/introShape1_2.png" alt="shape"></div>
                    <div class="shape3 d-none d-xxl-block cir36"><img src="assets/images/shape/introShape1_3.png"
                            alt="shape"></div>
                    <div class="shape4 d-none d-xxl-block cir36"><img src="assets/images/shape/introShape1_4.png"
                            alt="shape"></div>
                    <div class="shape5 d-none d-xxl-block cir36"><img src="assets/images/shape/introShape1_5.png"
                            alt="shape"></div>
                    <div class="container">
                        <div class="row">
                            <div class="col-xl-7 order-2 order-xl-1">
                                <div class="intro-content">
                                    <div class="intro-section-title">
                                        <div class="intro-subtitle">
                                            <span>News!</span>Find Your Solution <img
                                                src="assets/images/icon/fireIcon.svg" alt="icon">
                                        </div>
                                        <h1 class="intro-title wow fadeInUp" data-wow-delay=".2s">We Develop Websites,
                                            Applications, and Brands.</h1>
                                        <p class="intro-desc wow fadeInUp" data-wow-delay=".4s">There are many
                                            variations of passages of Lorem Ipsum
                                            available, but the majority have suffered alteration in some form, by
                                            injected humour, or randomised words which don't look even slightly
                                            believable. If you are going to use a passage of Lorem Ipsum,</p>
                                    </div>
                                    <div class="btn-wrapper style1 wow fadeInUp" data-wow-delay=".6s">
                                        <a class="theme-btn" href="contact.html">Get Started Now
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                viewBox="0 0 16 16" fill="none">
                                                <g clip-path="url(#clip0_11_22)">
                                                    <path
                                                        d="M11.6118 3.61182L10.8991 4.32454L14.0706 7.49603H0V8.50398H14.0706L10.8991 11.6754L11.6118 12.3882L16 7.99997L11.6118 3.61182Z"
                                                        fill="white" />
                                                </g>
                                                <defs>
                                                    <clipPath id="clip0_11_22">
                                                        <rect width="16" height="16" fill="white" />
                                                    </clipPath>
                                                </defs>
                                            </svg>

                                        </a>
                                        <a class="theme-btn style2 wow fadeInUp" data-wow-delay=".2s"
                                            href="{{ route('about') }}">Learn More
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                viewBox="0 0 16 16" fill="none">
                                                <g clip-path="url(#clip0_11_27)">
                                                    <path
                                                        d="M11.6118 3.61182L10.8991 4.32454L14.0706 7.49603H0V8.50398H14.0706L10.8991 11.6754L11.6118 12.3882L16 7.99997L11.6118 3.61182Z"
                                                        fill="#282C32" />
                                                </g>
                                                <defs>
                                                    <clipPath id="clip0_11_27">
                                                        <rect width="16" height="16" fill="white" />
                                                    </clipPath>
                                                </defs>
                                            </svg>
                                        </a>
                                    </div>
                                    <div class="fancy-box-wrapper style1">
                                        <div class="fancy-box style1 wow fadeInUp" data-wow-delay=".2s">
                                            <div class="item">
                                                <img src="assets/images/intro/introProfileThumb1_1.png" alt="thumb">
                                            </div>
                                            <div class="item">
                                                <h6>2,291</h6>
                                                <p>Happy Customers</p>
                                            </div>
                                        </div>
                                        <div class="fancy-box style5 wow fadeInUp" data-wow-delay=".4s">
                                            <h6>4.8/5</h6>
                                            <div class="rating">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="77" height="13"
                                                    viewBox="0 0 77 13" fill="none">
                                                    <g clip-path="url(#clip0_20_34)">
                                                        <path
                                                            d="M12.3738 4.23335L8.62048 3.8926L7.13714 0.419814C7.02762 0.164672 6.77843 0 6.50107 0C6.22371 0 5.97442 0.164672 5.8656 0.419814L4.38226 3.8926L0.62834 4.23335C0.353159 4.25875 0.120139 4.44515 0.0340334 4.70793C-0.0515761 4.9712 0.0274862 5.25997 0.235608 5.4425L3.07282 7.93034L2.23627 11.6148C2.17506 11.8857 2.28022 12.1659 2.505 12.3284C2.62583 12.4162 2.76778 12.46 2.91023 12.46C3.03265 12.46 3.15516 12.4275 3.26458 12.362L6.50107 10.4268L9.73697 12.362C9.97436 12.5038 10.2728 12.4909 10.4971 12.3284C10.7219 12.1659 10.8271 11.8857 10.7659 11.6148L9.92932 7.93034L12.7665 5.4425C12.9746 5.25997 13.0537 4.9718 12.9681 4.70793C12.8825 4.44465 12.649 4.25825 12.3738 4.23335Z"
                                                            fill="#ECC132" />
                                                        <path
                                                            d="M28.3758 4.23335L24.6224 3.8926L23.1391 0.419814C23.0296 0.164672 22.7804 0 22.503 0C22.2257 0 21.9764 0.164672 21.8676 0.419814L20.3842 3.8926L16.6303 4.23335C16.3551 4.25875 16.1221 4.44515 16.036 4.70793C15.9504 4.9712 16.0294 5.25997 16.2376 5.4425L19.0748 7.93034L18.2382 11.6148C18.177 11.8857 18.2822 12.1659 18.507 12.3284C18.6278 12.4162 18.7697 12.46 18.9122 12.46C19.0346 12.46 19.1571 12.4275 19.2665 12.362L22.503 10.4268L25.7389 12.362C25.9763 12.5038 26.2748 12.4909 26.4991 12.3284C26.7239 12.1659 26.829 11.8857 26.7678 11.6148L25.9313 7.93034L28.7685 5.4425C28.9765 5.25997 29.0557 4.9718 28.9701 4.70793C28.8845 4.44465 28.6509 4.25825 28.3758 4.23335Z"
                                                            fill="#ECC132" />
                                                        <path
                                                            d="M44.3777 4.23335L40.6244 3.8926L39.141 0.419814C39.0315 0.164672 38.7823 0 38.505 0C38.2276 0 37.9783 0.164672 37.8695 0.419814L36.3862 3.8926L32.6322 4.23335C32.3571 4.25875 32.124 4.44515 32.0379 4.70793C31.9523 4.9712 32.0314 5.25997 32.2395 5.4425L35.0767 7.93034L34.2402 11.6148C34.179 11.8857 34.2841 12.1659 34.5089 12.3284C34.6297 12.4162 34.7717 12.46 34.9141 12.46C35.0366 12.46 35.1591 12.4275 35.2685 12.362L38.505 10.4268L41.7409 12.362C41.9783 12.5038 42.2768 12.4909 42.501 12.3284C42.7258 12.1659 42.831 11.8857 42.7698 11.6148L41.9332 7.93034L44.7704 5.4425C44.9785 5.25997 45.0576 4.9718 44.972 4.70793C44.8864 4.44465 44.6529 4.25825 44.3777 4.23335Z"
                                                            fill="#ECC132" />
                                                        <path
                                                            d="M60.3797 4.23335L56.6263 3.8926L55.143 0.419814C55.0335 0.164672 54.7843 0 54.5069 0C54.2296 0 53.9803 0.164672 53.8715 0.419814L52.3881 3.8926L48.6342 4.23335C48.359 4.25875 48.126 4.44515 48.0399 4.70793C47.9543 4.9712 48.0333 5.25997 48.2415 5.4425L51.0787 7.93034L50.2421 11.6148C50.1809 11.8857 50.2861 12.1659 50.5109 12.3284C50.6317 12.4162 50.7736 12.46 50.9161 12.46C51.0385 12.46 51.161 12.4275 51.2704 12.362L54.5069 10.4268L57.7428 12.362C57.9802 12.5038 58.2787 12.4909 58.503 12.3284C58.7278 12.1659 58.8329 11.8857 58.7717 11.6148L57.9352 7.93034L60.7724 5.4425C60.9804 5.25997 61.0596 4.9718 60.974 4.70793C60.8884 4.44465 60.6548 4.25825 60.3797 4.23335Z"
                                                            fill="#ECC132" />
                                                        <path opacity="0.3"
                                                            d="M76.3816 4.23335L72.6283 3.8926L71.145 0.419814C71.0354 0.164672 70.7862 0 70.5089 0C70.2315 0 69.9822 0.164672 69.8734 0.419814L68.3901 3.8926L64.6362 4.23335C64.361 4.25875 64.128 4.44515 64.0418 4.70793C63.9562 4.9712 64.0353 5.25997 64.2434 5.4425L67.0806 7.93034L66.2441 11.6148C66.1829 11.8857 66.288 12.1659 66.5128 12.3284C66.6336 12.4162 66.7756 12.46 66.918 12.46C67.0405 12.46 67.163 12.4275 67.2724 12.362L70.5089 10.4268L73.7448 12.362C73.9822 12.5038 74.2807 12.4909 74.505 12.3284C74.7297 12.1659 74.8349 11.8857 74.7737 11.6148L73.9371 7.93034L76.7743 5.4425C76.9824 5.25997 77.0615 4.9718 76.9759 4.70793C76.8903 4.44465 76.6568 4.25825 76.3816 4.23335Z"
                                                            fill="#565656" />
                                                    </g>
                                                    <defs>
                                                        <clipPath id="clip0_20_34">
                                                            <rect width="77.0099" height="12.46" fill="white" />
                                                        </clipPath>
                                                    </defs>
                                                </svg>
                                                Rating
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-5 order-1 order-xl-2">
                                <div class="intro-thumb">
                                    <div class="thumbShape1"><img src="assets/images/shape/introThumbShape1_1.png"
                                            alt="thumbShape"></div>
                                    <div class="thumbShape2"><img src="assets/images/shape/introThumbShape1_2.png"
                                            alt="thumbShape"></div>
                                    <img class="main-thumb img-custom-anim-right wow fadeInUp" data-wow-delay=".4s"
                                        src="assets/images/intro/introThumb1_1.png" alt="thumb">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Brand Slider Section S T A R T -->
    <div class="brand-slider-section section-padding fix">
        <div class="brand-slider-container-wrapper style1">
            <div class="container">
                <div class="brand-slider-wrapper style1">
                    <h2 class="single-section-title wow fadeInUp" data-wow-delay=".2s">
                        Millions of clients trust us.
                    </h2>
                    <div class="row">
                        <div class="slider-area brandSliderOne">
                            <div class="swiper gt-slider" id="brandSliderOne"
                                data-slider-options='{"loop": true,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":2,"centeredSlides":true},"768":{"slidesPerView":3},"1025":{"slidesPerView":4},"1400":{"slidesPerView":5}}}'>
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="brand-logo">
                                            <img src="assets/images/logo/brandLogo1_1.png" alt="logo">
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="brand-logo">
                                            <img src="assets/images/logo/brandLogo1_2.png" alt="logo">
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="brand-logo">
                                            <img src="assets/images/logo/brandLogo1_3.png" alt="logo">
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="brand-logo">
                                            <img src="assets/images/logo/brandLogo1_4.png" alt="logo">
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="brand-logo">
                                            <img src="assets/images/logo/brandLogo1_5.png" alt="logo">
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="brand-logo">
                                            <img src="assets/images/logo/brandLogo1_3.png" alt="logo">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- About Us Section S T A R T -->
    <section class="about-section fix">
        <div class="about-container-wrapper style1">
            <div class="container">
                <div class="about-wrapper style1">
                    <div class="row gy-5 gx-60">
                        <div class="col-xl-6">
                            <div class="about-thumb">
                                <div class="bg"></div>
                                <div class="thumbShape1 d-none d-xxl-block cir36"><img
                                        src="assets/images/shape/aboutThumbShape1_1.png" alt="shape"></div>
                                <div class="thumbShape2 d-none d-xxl-block cir36"><img
                                        src="assets/images/shape/aboutThumbShape1_2.png" alt="shape"></div>
                                <div class="thumbShape3 d-none d-xxl-block cir36 float-bob-y"><img
                                        src="assets/images/shape/aboutThumbShape1_3.png" alt="shape"></div>
                                <div class="thumbShape4 d-none d-xxl-block cir36"><img
                                        src="assets/images/shape/aboutThumbShape1_4.png" alt="shape"></div>
                                <div class="main-thumb">
                                    <img src="assets/images/about/aboutThumb1_1.png" alt="thumb">
                                </div>
                                <div class="absolute-thumb float-bob-x">
                                    <img src="assets/images/about/aboutThumb1_2.png" alt="thumb">
                                </div>

                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="about-content">
                                <div class="section-title">
                                    <div class="subtitle wow fadeInUp" data-wow-delay=".2s">
                                        About Our App <img src="assets/images/icon/fireIcon.svg" alt="icon">
                                    </div>
                                    <h2 class="title wow fadeInUp" data-wow-delay=".4s">Simple Reports & Analytics
                                        Backdown As it</h2>
                                    <p class="section-desc wow fadeInUp" data-wow-delay=".6s">There are many variations
                                        of passages of Lorem Ipsum
                                        available, but the majority have suffered alteration in some form, by injected
                                        humour, or randomised words which don't look even slightly believable. If you
                                        are going to use</p>
                                </div>
                                <ul class="checklist style1 wow fadeInUp" data-wow-delay=".2s">
                                    <li><img src="assets/images/icon/checkmarkIcon.svg" alt="icon"> With our
                                        Technological and Marketing Solutions.</li>
                                    <li><img src="assets/images/icon/checkmarkIcon.svg" alt="icon"> We are trusted all
                                        over the world. </li>
                                    <li><img src="assets/images/icon/checkmarkIcon.svg" alt="icon"> Start Your 14 Days
                                        Free Trials Today! </li>
                                </ul>
                                <a class="theme-btn wow fadeInUp" data-wow-delay=".2s" href="{{ route('about') }}">Discover More
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"
                                        fill="none">
                                        <g clip-path="url(#clip0_18_41)">
                                            <path
                                                d="M11.6118 3.61182L10.8991 4.32454L14.0706 7.49603H0V8.50398H14.0706L10.8991 11.6754L11.6118 12.3882L16 7.99997L11.6118 3.61182Z"
                                                fill="white" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_18_41">
                                                <rect width="16" height="16" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Work Process Section S T A R T -->
    <section class="work-process-section section-padding fix">
        <div class="work-process-container-wrapper style1">
            <div class="container">
                <div class="section-title text-center mxw-565 mx-auto">
                    <div class="subtitle wow fadeInUp" data-wow-delay=".2s">
                        How It Work <img src="assets/images/icon/fireIcon.svg" alt="icon">
                    </div>
                    <h2 class="title wow fadeInUp" data-wow-delay=".4s">Make Your Device Manage Everything For You!</h2>
                </div>
                <div class="work-process-wrapper style1">
                    <div class="shape"><img src="assets/images/shape/workProcessShape1_1.png" alt="shape"></div>
                    <div class="row">
                        <div class="col-xl-4">
                            <div class="work-process-box style1 wow fadeInUp" data-wow-delay=".2s">
                                <div class="step">STEP - 01</div>
                                <div class="title">Download App</div>
                                <div class="text">There are many variations of passages of Lorem</div>
                            </div>
                        </div>
                        <div class="col-xl-4">
                            <div class="work-process-box style1 child2 wow fadeInUp" data-wow-delay=".4s">
                                <div class="step">STEP - 02</div>
                                <div class="title">Create account</div>
                                <div class="text">There are many variations of passages of Lorem</div>
                            </div>
                        </div>
                        <div class="col-xl-4">
                            <div class="work-process-box style1 wow fadeInUp" data-wow-delay=".6s">
                                <div class="step">STEP - 03</div>
                                <div class="title">Install App, & Enjoy</div>
                                <div class="text">There are many variations of passages of Lorem</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Advantage Section S T A R T -->
    <section class="advantage-section fix">
        <div class="advantage-container-wrapper style1">
            <div class="container">
                <div class="advantage-wrapper style1 section-padding">
                    <div class="container">
                        <div class="row gy-5 d-flex align-items-center">
                            <div class="col-xl-6 order-2 order-xl-1">
                                <div class="advantage-content">
                                    <div class="section-title wow fadeInUp" data-wow-delay=".2s">
                                        <div class="subtitle">
                                            App Advantage <img src="assets/images/icon/fireIcon.svg" alt="icon">
                                        </div>
                                        <h2 class="title">Get Benefit By Using Trending Apps</h2>
                                        <p class="section-desc">There are many variations of passages of Lorem Ipsum
                                            available, but the majority have suffered alteration in some form, by
                                            injected humour, or randomised words which don't look even slightly</p>
                                    </div>
                                    <div class="checklist-wrapper style1 wow fadeInUp" data-wow-delay=".4s">
                                        <ul class="checklist style1">
                                            <li><img src="assets/images/icon/checkmarkIcon.svg" alt="icon"> Friendly
                                                Design</li>
                                            <li><img src="assets/images/icon/checkmarkIcon.svg" alt="icon">SEO Optimized
                                            </li>
                                        </ul>
                                        <ul class="checklist style1">
                                            <li><img src="assets/images/icon/checkmarkIcon.svg" alt="icon"> Cloud
                                                Storage </li>
                                            <li><img src="assets/images/icon/checkmarkIcon.svg" alt="icon"> Strong
                                                Security </li>
                                        </ul>
                                    </div>
                                    <a class="theme-btn wow fadeInUp" data-wow-delay=".6s" href="{{ route('about') }}"> Download
                                        App
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                            viewBox="0 0 16 16" fill="none">
                                            <g clip-path="url(#clip0_43_54)">
                                                <path
                                                    d="M11.6118 3.61182L10.8991 4.32454L14.0706 7.49603H0V8.50398H14.0706L10.8991 11.6754L11.6118 12.3882L16 7.99997L11.6118 3.61182Z"
                                                    fill="white" />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_43_54">
                                                    <rect width="16" height="16" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-6 order-1 order-xl-2">
                                <div class="advantage-thumb">
                                    <div class="thumb1 img-custom-anim-top wow fadeInDown" data-wow-delay=".8s"
                                        data-tilt data-tilt-max="10"><img
                                            src="assets/images/advantage/advantageThumb1_1.png" alt="thumb"></div>
                                    <div class="thumb2 img-custom-anim-right wow fadeInRight" data-wow-delay=".4s"
                                        data-tilt data-tilt-max="15"><img
                                            src="assets/images/advantage/advantageThumb1_2.png" alt="thumb"></div>
                                    <div class="shape1"><img src="assets/images/shape/advanceThumbShape1_1.png"
                                            alt="shape"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Wcu Section S T A R T -->
    <section class="wcu-section section-padding fix">
        <div class="wcu-container-wrapper style1">
            <div class="container">
                <div class="section-title text-center mxw-685 mx-auto wow fadeInUp" data-wow-delay=".2s">
                    <div class="subtitle">
                        Why using our app<img src="assets/images/icon/fireIcon.svg" alt="icon">
                    </div>
                    <h2 class="title">Our app is great for individuals, startups and enterprises</h2>
                </div>
                <div class="wcu-wrapper style1">
                    <div class="row gy-5 d-flex justify-content-center">
                        <div class="col-xl-4 d-flex justify-content-center">
                            <div class="wcu-content">
                                <div class="fancy-box style2">
                                    <div class="icon"><img src="assets/images/icon/wcuIcon1_1.svg" alt="icon"></div>
                                    <div class="content wow fadeInUp" data-wow-delay=".2s">
                                        <h4>High usability</h4>
                                        <p class="text">There are many variations of passages of Lorem Ipsum</p>
                                    </div>
                                </div>
                                <div class="fancy-box style2 wow fadeInUp" data-wow-delay=".4s">
                                    <div class="icon"><img src="assets/images/icon/wcuIcon1_2.svg" alt="icon"></div>
                                    <div class="content">
                                        <h4>Action Reminder</h4>
                                        <p class="text">There are many variations of passages of Lorem Ipsum</p>
                                    </div>
                                </div>
                                <div class="fancy-box style2 wow fadeInUp" data-wow-delay=".6s">
                                    <div class="icon"><img src="assets/images/icon/wcuIcon1_3.svg" alt="icon"></div>
                                    <div class="content">
                                        <h4>Merge Files</h4>
                                        <p class="text">There are many variations of passages of Lorem Ipsum</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 d-flex justify-content-center">
                            <div class="wcu-thumb wow fadeInUp" data-wow-delay=".2s">
                                <div class="main-thumb wow bounceInUp" data-wow-delay=".6s"><img
                                        src="assets/images/wcu/wcuThumb1_1.png" alt="thumb"></div>
                                <div class="shape"><img src="assets/images/shape/wcuThumbShape1_1.png" alt="shape">
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 d-flex justify-content-center justify-content-xl-end">
                            <div class="wcu-content">
                                <div class="fancy-box style2 wow fadeInUp" data-wow-delay=".2s">
                                    <div class="icon"><img src="assets/images/icon/wcuIcon1_4.svg" alt="icon"></div>
                                    <div class="content">
                                        <h4>Free Live Chat</h4>
                                        <p class="text">There are many variations of passages of Lorem Ipsum</p>
                                    </div>
                                </div>
                                <div class="fancy-box style2 wow fadeInUp" data-wow-delay=".4s">
                                    <div class="icon"><img src="assets/images/icon/wcuIcon1_5.svg" alt="icon"></div>
                                    <div class="content">
                                        <h4>Social Share</h4>
                                        <p class="text">There are many variations of passages of Lorem Ipsum</p>
                                    </div>
                                </div>
                                <div class="fancy-box style2 wow fadeInUp" data-wow-delay=".6s">
                                    <div class="icon"><img src="assets/images/icon/wcuIcon1_6.svg" alt="icon"></div>
                                    <div class="content">
                                        <h4>Custom Shortcuts</h4>
                                        <p class="text">There are many variations of passages of Lorem Ipsum</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Counter Section S T A R T -->
    <div class="counter-section fix">
        <div class="counter-container-wrapper style1">
            <div class="container">
                <div class="counter-wrapper style1 section-padding"
                    data-bg-src="assets/images/shape/counterShape1_1.png">
                    <div class="shape"></div>
                    <div class="container">
                        <div class="row gy-5">
                            <div class="col-xl-3 col-md-6 d-flex justify-content-center">
                                <div class="counter-box style1 wow fadeInUp" data-wow-delay=".2s">
                                    <div class="counter">
                                        <span class="counter-number">56</span> <span class="plus">+</span>
                                    </div>
                                    <p class="text">Customers visit app every months</p>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 d-flex justify-content-center">
                                <div class="counter-box style1 wow fadeInUp" data-wow-delay=".4s">
                                    <div class="counter">
                                        <span class="counter-number">32</span> <span class="plus">+</span>
                                    </div>
                                    <p class="text">Total downloaded of our app</p>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 d-flex justify-content-center">
                                <div class="counter-box style1 wow fadeInUp" data-wow-delay=".6s">
                                    <div class="counter">
                                        <span class="counter-number">156</span> <span class="plus">k</span>
                                    </div>
                                    <p class="text">Total Members of App Users</p>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 d-flex justify-content-center">
                                <div class="counter-box style1 wow fadeInUp" data-wow-delay=".8s">
                                    <div class="counter">
                                        <span class="counter-number">42</span> <span class="plus">+</span>
                                    </div>
                                    <p class="text">Satisfaction rate from our customers.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Faq Section S T A R T -->
    <section class="faq-section section-padding fix">
        <div class="container">
            <div class="faq-wrapper style1">
                <div class="row gy-5 gy-xl-0 gx-60 d-flex align-items-start">
                    <div class="col-xl-6">
                        <div class="faq-content style1">
                            <div class="section-title">
                                <div class="subtitle wow fadeInUp" data-wow-delay=".2s">
                                    FAQs <img src="assets/images/icon/fireIcon.svg" alt="icon">
                                </div>
                                <h2 class="title wow fadeInUp" data-wow-delay=".4s">Frequently Ask Questions</h2>
                                <p class="section-desc wow fadeInUp" data-wow-delay=".6s">There are many variations of
                                    passages of Lorem Ipsum available,
                                    but the majority have suffered alteration in some form, by injected humour, or
                                    randomised words which don't look even slightly</p>
                            </div>
                            <div class="faq-accordion">
                                <div class="accordion" id="accordion">
                                    <div class="accordion-item mb-3 wow fadeInUp" data-wow-delay=".3s">
                                        <h5 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#faq1" aria-expanded="true"
                                                aria-controls="faq1">
                                                Looking for a solution to boost productivity?
                                            </button>
                                        </h5>
                                        <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#accordion">
                                            <div class="accordion-body">
                                                There are many variations of passages of Lorem Ipsum available, but the
                                                majority have suffered alteration in some form, by injected humour, or
                                                randomised words which don't look even slightly
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item mb-3 wow fadeInUp" data-wow-delay=".5s">
                                        <h5 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#faq2" aria-expanded="false"
                                                aria-controls="faq2">
                                                Need an easy way to manage your projects?
                                            </button>
                                        </h5>
                                        <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#accordion">
                                            <div class="accordion-body">
                                                There are many variations of passages of Lorem Ipsum available, but the
                                                majority have suffered alteration in some form, by injected humour, or
                                                randomised words which don't look even slightly
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item mb-3 wow fadeInUp" data-wow-delay=".7s">
                                        <h5 class="accordion-header">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#faq3" aria-expanded="false" aria-controls="faq3">
                                                Seeking a user-friendly solution for your team?
                                            </button>
                                        </h5>
                                        <div id="faq3" class="accordion-collapse show" data-bs-parent="#accordion">
                                            <div class="accordion-body">
                                                There are many variations of passages of Lorem Ipsum available, but the
                                                majority have suffered alteration in some form, by injected humour, or
                                                randomised words which don't look even slightly
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="faq-thumb">
                            <img class="main-thumb  wow fadeInUp" data-wow-delay=".2s"
                                src="assets/images/faq/faqThumb1_2.png" alt="thumb">
                            <div class="absolute-thumb float-bob-x">
                                <img src="assets/images/faq/faqThumb1_1.png" alt="thumb">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonial Section S T A R T -->
    <section class="testimonial-section">
        <div class="testimonial-container-wrapper style1">
            <div class="container">
                <div class="testimonial-wrapper style1 section-padding fix">
                    <div class="shape1"><img src="assets/images/shape/testimonialShape1_1.png" alt="shape"></div>
                    <div class="shape2"><img src="assets/images/shape/testimonialShape1_2.png" alt="shape"></div>
                    <div class="container">
                        <div class="section-title text-center mxw-685 mx-auto">
                            <div class="subtitle">
                                Testimonial <img src="assets/images/icon/fireIcon.svg" alt="icon">
                            </div>
                            <h2 class="title">What our clients say?</h2>
                        </div>
                        <div class="slider-area testimonialSliderOne">
                            <div class="swiper gt-slider" id="testimonialSliderOne"
                                data-slider-options='{"loop": true,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":1,"centeredSlides":true},"768":{"slidesPerView":2},"992":{"slidesPerView":2},"1200":{"slidesPerView":3}}}'>
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="testimonial-card style1">
                                            <div class="testimonial-header">
                                                <div class="profile-thumb">
                                                    <img src="assets/images/testimoial/testimonialProfileThumb1_1.jpg"
                                                        alt="thumb">
                                                </div>
                                                <div class="content">
                                                    <h5>Jacob Jones</h5>
                                                    <p class="text">Team Leader</p>
                                                </div>
                                            </div>
                                            <div class="testimonial-body">
                                                <ul class="star-wrapper style1">
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                </ul>
                                                <p class="desc">There are many variations of passages of Lorem Ipsum
                                                    available,a but
                                                    chiropractor like majority have a suffered alteration in some form,
                                                    by injected humour,</p>
                                            </div>
                                            <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg"
                                                    alt="icon"></div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="testimonial-card style1">
                                            <div class="testimonial-header">
                                                <div class="profile-thumb">
                                                    <img src="assets/images/testimoial/testimonialProfileThumb1_2.jpg"
                                                        alt="thumb">
                                                </div>
                                                <div class="content">
                                                    <h5>Masirul Jones</h5>
                                                    <p class="text">Team Leader</p>
                                                </div>
                                            </div>
                                            <div class="testimonial-body">
                                                <ul class="star-wrapper style1">
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                </ul>
                                                <p class="desc">There are many variations of passages of Lorem Ipsum
                                                    available,a but
                                                    chiropractor like majority have a suffered alteration in some form,
                                                    by injected humour,</p>
                                            </div>
                                            <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg"
                                                    alt="icon"></div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="testimonial-card style1">
                                            <div class="testimonial-header">
                                                <div class="profile-thumb">
                                                    <img src="assets/images/testimoial/testimonialProfileThumb1_3.jpg"
                                                        alt="thumb">
                                                </div>
                                                <div class="content">
                                                    <h5>Adam Jones</h5>
                                                    <p class="text">Team Leader</p>
                                                </div>
                                            </div>
                                            <div class="testimonial-body">
                                                <ul class="star-wrapper style1">
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                </ul>
                                                <p class="desc">There are many variations of passages of Lorem Ipsum
                                                    available,a but
                                                    chiropractor like majority have a suffered alteration in some form,
                                                    by injected humour,</p>
                                            </div>
                                            <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg"
                                                    alt="icon"></div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="testimonial-card style1">
                                            <div class="testimonial-header">
                                                <div class="profile-thumb">
                                                    <img src="assets/images/testimoial/testimonialProfileThumb1_1.jpg"
                                                        alt="thumb">
                                                </div>
                                                <div class="content">
                                                    <h5>Wade Warren</h5>
                                                    <p class="text">Team Leader</p>
                                                </div>
                                            </div>
                                            <div class="testimonial-body">
                                                <ul class="star-wrapper style1">
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                </ul>
                                                <p class="desc">There are many variations of passages of Lorem Ipsum
                                                    available,a but
                                                    chiropractor like majority have a suffered alteration in some form,
                                                    by injected humour,</p>
                                            </div>
                                            <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg"
                                                    alt="icon"></div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="testimonial-card style1">
                                            <div class="testimonial-header">
                                                <div class="profile-thumb">
                                                    <img src="assets/images/testimoial/testimonialProfileThumb1_2.jpg"
                                                        alt="thumb">
                                                </div>
                                                <div class="content">
                                                    <h5>Masirul Jones</h5>
                                                    <p class="text">Team Leader</p>
                                                </div>
                                            </div>
                                            <div class="testimonial-body">
                                                <ul class="star-wrapper style1">
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                </ul>
                                                <p class="desc">There are many variations of passages of Lorem Ipsum
                                                    available,a but
                                                    chiropractor like majority have a suffered alteration in some form,
                                                    by injected humour,</p>
                                            </div>
                                            <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg"
                                                    alt="icon"></div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="testimonial-card style1">
                                            <div class="testimonial-header">
                                                <div class="profile-thumb">
                                                    <img src="assets/images/testimoial/testimonialProfileThumb1_3.jpg"
                                                        alt="thumb">
                                                </div>
                                                <div class="content">
                                                    <h5>Adam Jones</h5>
                                                    <p class="text">Team Leader</p>
                                                </div>
                                            </div>
                                            <div class="testimonial-body">
                                                <ul class="star-wrapper style1">
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                    <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                                </ul>
                                                <p class="desc">There are many variations of passages of Lorem Ipsum
                                                    available,a but
                                                    chiropractor like majority have a suffered alteration in some form,
                                                    by injected humour,</p>
                                            </div>
                                            <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg"
                                                    alt="icon"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="slider-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Feature Section S T A R T -->
    <section class="feature-section section-padding fix">
        <div class="container">
            <div class="feature-wrapper style1">
                <div class="row gy-5 gx-134">
                    <div class="col-xl-6 order-2 order-xl-1">
                        <div class="feature-content">
                            <div class="section-title">
                                <div class="subtitle wow fadeInUp" data-wow-delay=".2s">
                                    Our Features <img src="assets/images/icon/fireIcon.svg" alt="icon">
                                </div>
                                <h2 class="title wow fadeInUp" data-wow-delay=".4s">Our features will help to improve
                                    business</h2>
                                <p class="section-desc wow fadeInUp" data-wow-delay=".6s">There are many variations of
                                    passages of Lorem Ipsum available,
                                    but the majority have suffered alteration in some form, by injected humour, or
                                    randomised words which don't look even slightly</p>
                            </div>
                            <a class="theme-btn wow fadeInUp" data-wow-delay=".2s" href="contact.html">Start
                                Collaborator <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    viewBox="0 0 16 16" fill="none">
                                    <g clip-path="url(#clip0_91_29)">
                                        <path
                                            d="M11.6118 3.61182L10.8991 4.32454L14.0706 7.49603H0V8.50398H14.0706L10.8991 11.6754L11.6118 12.3882L16 7.99997L11.6118 3.61182Z"
                                            fill="white" />
                                    </g>
                                    <defs>
                                        <clipPath id="clip0_91_29">
                                            <rect width="16" height="16" fill="white" />
                                        </clipPath>
                                    </defs>
                                </svg>
                            </a>
                        </div>
                    </div>
                    <div class="col-xl-6 order-1 order-xl-2">
                        <div class="feature-box-wrapper">
                            <div class="feature-box style1 child1">
                                <div class="feature-box-header wow fadeInUp" data-wow-delay=".2s">
                                    <div class="content">
                                        <h5>Software development</h5>
                                        <p class="text">UX Research</p>
                                    </div>
                                    <div class="icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="34" height="35"
                                            viewBox="0 0 34 35" fill="none">
                                            <circle cx="17" cy="17.5" r="16" stroke="#F1F1F1" stroke-width="2" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="feature-box-footer wow fadeInUp" data-wow-delay=".4s">
                                    <div class="content">
                                        <span class="day">Today</span>
                                        <span class="time">07:02 AM</span>
                                    </div>
                                    <div class="shape"><img src="assets/images/shape/featureProfileShape1_1.png"
                                            alt="shape"></div>
                                </div>
                            </div>
                            <div class="feature-box style1 child2">
                                <div class="feature-box-header wow fadeInUp" data-wow-delay=".6s">
                                    <div class="content">
                                        <h5>Design data & analytics</h5>
                                        <p class="text">UX Research</p>
                                    </div>
                                    <div class="icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="34" height="35"
                                            viewBox="0 0 34 35" fill="none">
                                            <circle cx="17" cy="17.5" r="16" stroke="#F1F1F1" stroke-width="2" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="feature-box-footer wow fadeInUp" data-wow-delay=".6s">
                                    <div class="content">
                                        <span class="day">Today</span>
                                        <span class="time">07:02 AM</span>
                                    </div>
                                    <div class="shape"><img src="assets/images/shape/featureProfileShape1_1.png"
                                            alt="shape"></div>
                                </div>
                            </div>
                            <div class="feature-box style1 wow fadeInUp" data-wow-delay=".6s">
                                <div class="feature-box-header">
                                    <div class="content">
                                        <h5>Dedicated Support</h5>
                                        <p class="text">UX Research</p>
                                    </div>
                                    <div class="icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="34" height="35"
                                            viewBox="0 0 34 35" fill="none">
                                            <circle cx="17" cy="17.5" r="16" stroke="#F1F1F1" stroke-width="2" />
                                        </svg>
                                    </div>
                                </div>
                                <div class="feature-box-footer">
                                    <div class="content">
                                        <span class="day">Today</span>
                                        <span class="time">07:02 AM</span>
                                    </div>
                                    <div class="shape"><img src="assets/images/shape/featureProfileShape1_1.png"
                                            alt="shape"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Pricing Section S T A R T -->
    <section class="pricing-section section-padding pt-0 fix">
        <div class="container">
            <div class="section-title text-center mxw-685 mx-auto">
                <div class="subtitle">
                    Our Pricing <img src="assets/images/icon/fireIcon.svg" alt="icon">
                </div>
                <h2 class="title">Choose The Plans That Suits You!</h2>
                <p class="text">There are many variations of passages of Lorem Ipsum available, but the majority have
                </p>
            </div>
            <div class="pricing-wrapper style1">
                <div class="tab-section d-flex justify-content-center align-items-center">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-monthly-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-monthly" type="button" role="tab" aria-controls="pills-monthly"
                                aria-selected="true">Monthly</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-yearly-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-yearly" type="button" role="tab" aria-controls="pills-yearly"
                                aria-selected="false" tabindex="-1">Yearly</button>
                        </li>
                    </ul>
                </div>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade active show" id="pills-monthly" role="tabpanel"
                        aria-labelledby="pills-monthly-tab">
                        <div class="row gy-5">
                            <div class="col-xl-4 col-md-6">
                                <div class="pricing-card style1">
                                    <div class="pricing-card-header">
                                        <h6>Basic Plan</h6>
                                        <div class="price-wrapper">
                                            <span class="price">$14.99</span> <span class="text"> / Per Month</span>
                                        </div>
                                        <p class="text">There are many variations of passages of Lorem Ipsum available,
                                            but the
                                            majority</p>
                                    </div>
                                    <div class="pricing-card-body">
                                        <ul class="checklist">
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> 7 days free access
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Maximum of 5 collaborators
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Cloud backup 1GB
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#858585" />
                                                </svg> Maximum 50 tasks per week
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#858585" />
                                                </svg> 100+ HTML UI Elements
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#858585" />
                                                </svg> Updates for 1 Year
                                            </li>
                                        </ul>
                                    </div>
                                    <a class="theme-btn style5" href="pricing.html"> Get You Free plan </a>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6">
                                <div class="pricing-card style1">
                                    <div class="pricing-card-header">
                                        <h6>Standard Plan</h6>
                                        <div class="price-wrapper">
                                            <span class="price">$19.99</span> <span class="text"> / Per Month</span>
                                        </div>
                                        <p class="text">There are many variations of passages of Lorem Ipsum available,
                                            but the
                                            majority</p>
                                    </div>
                                    <div class="pricing-card-body">
                                        <ul class="checklist">
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> 7 days free access
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Maximum of 5 collaborators
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Cloud backup 1GB
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Maximum 50 tasks per week
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> 100+ HTML UI Elements
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Updates for 1 Year
                                            </li>
                                        </ul>
                                    </div>
                                    <a class="theme-btn style4" href="pricing.html"> Get You Free plan </a>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6">
                                <div class="pricing-card style1">
                                    <div class="pricing-card-header">
                                        <h6>Premium Plan Plan</h6>
                                        <div class="price-wrapper">
                                            <span class="price">$24.99</span> <span class="text"> / Per Month</span>
                                        </div>
                                        <p class="text">There are many variations of passages of Lorem Ipsum available,
                                            but the
                                            majority</p>
                                    </div>
                                    <div class="pricing-card-body">
                                        <ul class="checklist">
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> 7 days free access
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Maximum of 5 collaborators
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Cloud backup 1GB
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Maximum 50 tasks per week
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> 100+ HTML UI Elements
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#858585" />
                                                </svg> Updates for 1 Year
                                            </li>
                                        </ul>
                                    </div>
                                    <a class="theme-btn style5" href="pricing.html"> Get You Free plan </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-yearly" role="tabpanel" aria-labelledby="pills-yearly-tab">
                        <div class="row gy-5">
                            <div class="col-xl-4 col-md-6">
                                <div class="pricing-card style1">
                                    <div class="pricing-card-header">
                                        <h6>Basic Plan</h6>
                                        <div class="price-wrapper">
                                            <span class="price">$34.99</span> <span class="text"> / Per Month</span>
                                        </div>
                                        <p class="text">There are many variations of passages of Lorem Ipsum available,
                                            but the
                                            majority</p>
                                    </div>
                                    <div class="pricing-card-body">
                                        <ul class="checklist">
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> 7 days free access
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Maximum of 5 collaborators
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Cloud backup 1GB
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#858585" />
                                                </svg> Maximum 50 tasks per week
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#858585" />
                                                </svg> 100+ HTML UI Elements
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#858585" />
                                                </svg> Updates for 1 Year
                                            </li>
                                        </ul>
                                    </div>
                                    <a class="theme-btn style5" href="pricing.html"> Get You Free plan </a>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6">
                                <div class="pricing-card style1">
                                    <div class="pricing-card-header">
                                        <h6>Standard Plan</h6>
                                        <div class="price-wrapper">
                                            <span class="price">$64.99</span> <span class="text"> / Per Month</span>
                                        </div>
                                        <p class="text">There are many variations of passages of Lorem Ipsum available,
                                            but the
                                            majority</p>
                                    </div>
                                    <div class="pricing-card-body">
                                        <ul class="checklist">
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> 7 days free access
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Maximum of 5 collaborators
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Cloud backup 1GB
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Maximum 50 tasks per week
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> 100+ HTML UI Elements
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Updates for 1 Year
                                            </li>
                                        </ul>
                                    </div>
                                    <a class="theme-btn style4" href="pricing.html"> Get You Free plan </a>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6">
                                <div class="pricing-card style1">
                                    <div class="pricing-card-header">
                                        <h6>Premium Plan Plan</h6>
                                        <div class="price-wrapper">
                                            <span class="price">$84.99</span> <span class="text"> / Per Month</span>
                                        </div>
                                        <p class="text">There are many variations of passages of Lorem Ipsum available,
                                            but the
                                            majority</p>
                                    </div>
                                    <div class="pricing-card-body">
                                        <ul class="checklist">
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> 7 days free access
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Maximum of 5 collaborators
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Cloud backup 1GB
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> Maximum 50 tasks per week
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#1AD079" />
                                                </svg> 100+ HTML UI Elements
                                            </li>
                                            <li><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 15 15" fill="none">
                                                    <path opacity="0.992" fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M7.22393 0C10.1444 0.0048682 12.3871 1.22628 13.952 3.66423C15.1321 5.76513 15.3168 7.95136 14.5062 10.2229C13.3721 12.8859 11.3758 14.4614 8.51719 14.9495C5.62984 15.2424 3.28454 14.2622 1.48125 12.0088C-0.0776275 9.77987 -0.406074 7.37811 0.495906 4.80353C1.26674 2.9139 2.5754 1.53341 4.42187 0.662026C5.31983 0.270692 6.25384 0.0500183 7.22393 0ZM11.2269 4.43403C11.6225 4.43526 11.7508 4.62002 11.6118 4.98829C9.90797 6.93843 8.20413 8.8886 6.50032 10.8387C6.34295 10.9814 6.17359 10.9968 5.99226 10.8849C5.24811 9.89445 4.50399 8.904 3.75985 7.91352C3.63052 7.68883 3.67671 7.50922 3.89841 7.37466C3.99079 7.35412 4.08316 7.35412 4.17554 7.37466C4.74004 7.75441 5.30458 8.1342 5.86909 8.51396C6.02234 8.62678 6.18659 8.64729 6.36176 8.57554C7.97994 7.1872 9.60165 5.80667 11.2269 4.43403Z"
                                                        fill="#858585" />
                                                </svg> Updates for 1 Year
                                            </li>
                                        </ul>
                                    </div>
                                    <a class="theme-btn style5" href="pricing.html"> Get You Free plan </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Cta Section S T A R T -->
    <section class="cta-section">
        <div class="cta-container-wrapper style1">
            <div class="container">
                <div class="cta-wrapper style1  section-padding fix">
                    <div class="shape1 d-none d-xxl-block"><img src="assets/images/shape/ctaShape1_1.png" alt="shape">
                    </div>
                    <div class="shape2 d-none d-xxl-block"><img src="assets/images/shape/ctaShape1_2.png" alt="shape">
                    </div>
                    <div class="shape3 d-none d-xxl-block"><img src="assets/images/shape/ctaShape1_3.png" alt="shape">
                    </div>
                    <div class="shape4 d-none d-xxl-block"><img src="assets/images/shape/ctaShape1_4.png" alt="shape">
                    </div>
                    <div class="container">
                        <div class="row gy-5">
                            <div class="col-xl-8 order-2 order-xl-1">
                                <div class="cta-content">
                                    <div class="section-title">
                                        <div class="subtitle text-white bg2 wow fadeInUp" data-wow-delay=".2s">
                                            Our App <img src="assets/images/icon/fireIcon.svg" alt="icon">
                                        </div>
                                        <h2 class="title text-white wow fadeInUp" data-wow-delay=".4s">Download our app
                                            and start your free trail to get
                                            started today!</h2>
                                        <p class="section-desc text-white mxw-651 wow fadeInUp" data-wow-delay=".6s">
                                            There are many variations of passages
                                            of Lorem Ipsum available, but the majority have suffered alteration in some
                                            form, by injected humour, or randomised</p>
                                    </div>
                                    <a class="playstore" href="https://play.google.com/store"><img
                                            src="assets/images/cta/ctaplayStore1_1.png" alt="img"></a>
                                    <a href="https://www.apple.com/store"><img
                                            src="assets/images/cta/ctaAppleStore1_1.png" alt="img"></a>
                                </div>
                            </div>
                            <div class="col-xl-4 order-1 order-xl-2">
                                <div class="cta-thumb wow fadeInUp" data-wow-delay=".2s">
                                    <img src="assets/images/cta/ctaThumb1_1.png" alt="thumb">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Blog Section S T A R T -->
    <section class="blog-section section-padding fix">
        <div class="container">
            <div class="blog-wrapper style1">
                <div class="section-title text-center mxw-685 mx-auto">
                    <div class="subtitle wow fadeInUp" data-wow-delay=".2s">
                        Our Blog <img src="assets/images/icon/fireIcon.svg" alt="icon">
                    </div>
                    <h2 class="title wow fadeInUp" data-wow-delay=".4s">Recent Articles And Latest Blog</h2>
                </div>
                <div class="row gy-5">
                    <div class="col-xl-4 col-md-6">
                        <div class="blog-card style1 wow fadeInUp" data-wow-delay=".2s">
                            <div class="thumb">
                                <img src="assets/images/blog/blogThumb1_1.jpg" alt="thumb">
                            </div>
                            <div class="body">
                                <div class="tag-meta">
                                    <img src="assets/images/icon/FolderIcon.svg" alt="icon">
                                    Workplace
                                </div>
                                <h3><a href="blog-details.html">Services that printing at you is important</a></h3>
                                <div class="blog-meta">
                                    <div class="item child1">
                                        <span class="icon">
                                            <img src="assets/images/icon/userIcon.svg" alt="icon">
                                        </span>
                                        <span class="text">By Admin</span>
                                    </div>
                                    <div class="item">
                                        <span class="icon">
                                            <img src="assets/images/icon/calendar.svg" alt="icon">
                                        </span>
                                        <span class="text">Sep 30, 2024</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="blog-card style1 wow fadeInUp" data-wow-delay=".4s">
                            <div class="thumb">
                                <img src="assets/images/blog/blogThumb1_2.jpg" alt="thumb">
                            </div>
                            <div class="body">
                                <div class="tag-meta">
                                    <img src="assets/images/icon/FolderIcon.svg" alt="icon">
                                    Coding
                                </div>
                                <h3><a href="blog-details.html">A checklist to improve your daily routine</a></h3>
                                <div class="blog-meta">
                                    <div class="item child1">
                                        <span class="icon">
                                            <img src="assets/images/icon/userIcon.svg" alt="icon">
                                        </span>
                                        <span class="text">By Admin</span>
                                    </div>
                                    <div class="item">
                                        <span class="icon">
                                            <img src="assets/images/icon/calendar.svg" alt="icon">
                                        </span>
                                        <span class="text">Sep 30, 2024</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="blog-card style1 wow fadeInUp" data-wow-delay=".6s">
                            <div class="thumb">
                                <img src="assets/images/blog/blogThumb1_1.jpg" alt="thumb">
                            </div>
                            <div class="body">
                                <div class="tag-meta">
                                    <img src="assets/images/icon/FolderIcon.svg" alt="icon">
                                    Technology
                                </div>
                                <h3><a href="blog-details.html">That will help you get 1% better every day</a></h3>
                                <div class="blog-meta">
                                    <div class="item child1">
                                        <span class="icon">
                                            <img src="assets/images/icon/userIcon.svg" alt="icon">
                                        </span>
                                        <span class="text">By Admin</span>
                                    </div>
                                    <div class="item">
                                        <span class="icon">
                                            <img src="assets/images/icon/calendar.svg" alt="icon">
                                        </span>
                                        <span class="text">Sep 30, 2024</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Footer Section    S T A R T -->
    <footer class="footer-section position-relative">
        <div class="footer-widgets-wrapper style1 fix">
            <div class="shape1"><img src="assets/images/shape/footerShape1_1.png" alt="shape"></div>
            <div class="shape2"><img src="assets/images/shape/footerShape1_2.png" alt="shape"></div>
            <div class="shape3"><img src="assets/images/shape/footerShape1_3.png" alt="shape"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay=".2s">
                        <div class="single-footer-widget">
                            <div class="widget-head">
                                <a href="{{ route('home') }}">
                                    <img src="assets/images/logo/logo.svg" alt="logo-img">
                                </a>
                            </div>
                            <div class="footer-content">
                                <p>
                                    It is a long established fact that from will be distracted by the readable from when
                                    looking.
                                </p>
                                <div class="store-links">
                                    <div class="apple">
                                        <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="19" height="17"
                                                viewBox="0 0 19 17" fill="none">
                                                <path
                                                    d="M13.9741 0.148438C11.9982 0.148438 11.1631 1.09311 9.78702 1.09311C8.37612 1.09311 7.29994 0.155311 5.58766 0.155311C3.91164 0.155311 2.12437 1.1805 0.989386 2.92696C-0.604303 5.38978 -0.333787 10.0282 2.24738 13.9797C3.17066 15.3942 4.40366 16.9806 6.02087 16.9978H6.05028C7.45578 16.9978 7.87332 16.0757 9.8076 16.0649H9.837C11.7424 16.0649 12.1246 16.9924 13.5242 16.9924H13.5536C15.1709 16.9752 16.47 15.2175 17.3933 13.8083C18.0578 12.7949 18.3048 12.2863 18.8145 11.1398C15.0807 9.71985 14.4809 4.41664 18.1735 2.38344C17.0463 0.969377 15.4624 0.150401 13.9692 0.150401L13.9741 0.148438Z"
                                                    fill="white" />
                                            </svg> App Store</a>
                                    </div>
                                    <div class="play">
                                        <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="26" height="17"
                                                viewBox="0 0 26 17" fill="none">
                                                <path
                                                    d="M18.8732 5.50779L20.9775 1.64735C21.0339 1.54372 21.0493 1.42066 21.0204 1.30505C20.9914 1.18943 20.9204 1.09065 20.8229 1.03026C20.7748 1.00032 20.7215 0.980802 20.6661 0.97283C20.6108 0.964858 20.5545 0.968593 20.5005 0.983821C20.4466 0.999048 20.396 1.02546 20.3517 1.06154C20.3075 1.09761 20.2704 1.14263 20.2427 1.19398L18.1122 5.10427C16.4855 4.31717 14.6547 3.87902 12.6857 3.87902C10.7167 3.87902 8.88588 4.3177 7.25923 5.10427L5.12868 1.19398C5.07191 1.09044 4.97863 1.01502 4.86936 0.984319C4.76008 0.953616 4.64377 0.970142 4.546 1.03026C4.44823 1.09038 4.37702 1.18917 4.34803 1.3049C4.31904 1.42062 4.33464 1.54381 4.39141 1.64735L6.49075 5.50779C2.86386 7.58782 0.405796 11.4776 0 16.0313H25.3684C24.9626 11.4776 22.5046 7.58782 18.8732 5.50779ZM6.85988 12.2584C6.64958 12.2584 6.444 12.1924 6.26914 12.0687C6.09429 11.9449 5.958 11.7691 5.87752 11.5633C5.79705 11.3575 5.77599 11.1311 5.81702 10.9127C5.85804 10.6942 5.95931 10.4936 6.10802 10.3361C6.25672 10.1786 6.44618 10.0714 6.65244 10.0279C6.8587 9.98449 7.07249 10.0068 7.26678 10.092C7.46108 10.1772 7.62714 10.3216 7.74398 10.5068C7.86081 10.6919 7.92317 10.9097 7.92317 11.1324C7.92304 11.431 7.81097 11.7173 7.6116 11.9285C7.41222 12.1396 7.14184 12.2583 6.85988 12.2584ZM18.5036 12.2584C18.2935 12.2575 18.0883 12.1907 17.9141 12.0664C17.7398 11.9421 17.6042 11.7659 17.5244 11.56C17.4446 11.3542 17.4242 11.1279 17.4657 10.9098C17.5073 10.6917 17.6089 10.4915 17.7578 10.3345C17.9066 10.1775 18.0961 10.0707 18.3022 10.0276C18.5084 9.98453 18.7219 10.0071 18.916 10.0925C19.11 10.1778 19.2758 10.3222 19.3924 10.5073C19.5091 10.6923 19.5713 10.9099 19.5713 11.1324C19.5713 11.2804 19.5436 11.4271 19.49 11.5638C19.4364 11.7006 19.3579 11.8248 19.2589 11.9294C19.1599 12.034 19.0424 12.1169 18.9132 12.1733C18.7839 12.2298 18.6454 12.2587 18.5056 12.2584H18.5036Z"
                                                    fill="#242331" />
                                            </svg> Play Store</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-4 col-md-6 ps-lg-5 wow fadeInUp" data-wow-delay=".4s">
                        <div class="single-footer-widget">
                            <div class="widget-head">
                                <h3> Pages </h3>
                            </div>
                            <ul class="list-area">
                                <li>
                                    <a href="{{ route('home') }}">
                                        Home
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ route('about') }}">
                                        About Us
                                    </a>
                                </li>
                                <li>
                                    <a href="project1.html">
                                        Integrations
                                    </a>
                                </li>
                                <li>
                                    <a href="services.html">
                                        Features
                                    </a>
                                </li>
                                <li>
                                    <a href="pricing.html">
                                        Pricing
                                    </a>
                                </li>
                                <li>
                                    <a href="contact.html">
                                        Contact Us
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay=".8s">
                        <div class="single-footer-widget">
                            <div class="widget-head">
                                <h3> Utility Pages </h3>
                            </div>
                            <ul class="list-area">
                                <li>
                                    <a href="project1.html">
                                        Project
                                    </a>
                                </li>
                                <li>
                                    <a href="blog.html">
                                        Blog
                                    </a>
                                </li>
                                <li>
                                    <a href="contact.html">
                                        Contact
                                    </a>
                                </li>
                                <li>
                                    <a href="pricing.html">
                                        Pricing
                                    </a>
                                </li>
                                <li>
                                    <a href="project-details.html">
                                        Project details
                                    </a>
                                </li>
                                <li>
                                    <a href="team.html">
                                        Our Team
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="single-footer-widget">
                            <div class="contact-box">
                                <div class="subtitle">Address</div>
                                <div class="widget-head">Ready to get started?</div>
                                <div class="text">It is a long established fact that a reader will be distracted layout.
                                </div>
                                <div class="info">
                                    <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="23"
                                            viewBox="0 0 22 23" fill="none">
                                            <path
                                                d="M3.66671 4.16699H18.3334C19.3417 4.16699 20.1667 4.99199 20.1667 6.00033V17.0003C20.1667 18.0087 19.3417 18.8337 18.3334 18.8337H3.66671C2.65837 18.8337 1.83337 18.0087 1.83337 17.0003V6.00033C1.83337 4.99199 2.65837 4.16699 3.66671 4.16699Z"
                                                stroke="#5236FF" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path d="M20.1667 6L11 12.4167L1.83337 6" stroke="#5236FF" stroke-width="2"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    <div class="link">
                                        <a href="mailto:contact.tech@gmail.com">contact.tech@gmail.com</a> <br>
                                        <a href="mailto:info@Niotech.com">info@Niotech.com</a>
                                    </div>
                                </div>
                                <div class="info">
                                    <div class="icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="23"
                                            viewBox="0 0 22 23" fill="none">
                                            <g clip-path="url(#clip0_2011_91)">
                                                <path
                                                    d="M13.7959 5.08366C14.6912 5.25834 15.514 5.69623 16.1591 6.34127C16.8041 6.9863 17.242 7.80915 17.4167 8.70449L13.7959 5.08366ZM13.7959 1.41699C15.656 1.62364 17.3906 2.45665 18.7149 3.77925C20.0392 5.10185 20.8744 6.83542 21.0834 8.69533L13.7959 1.41699ZM20.1667 16.0103V18.7603C20.1677 19.0156 20.1154 19.2683 20.0132 19.5022C19.9109 19.7361 19.7609 19.9461 19.5728 20.1187C19.3846 20.2913 19.1625 20.4227 18.9207 20.5045C18.6789 20.5863 18.4226 20.6166 18.1684 20.5937C15.3476 20.2872 12.6381 19.3233 10.2575 17.7795C8.0427 16.3721 6.16491 14.4943 4.75752 12.2795C3.20833 9.8881 2.24424 7.1654 1.94335 4.33199C1.92045 4.0785 1.95057 3.82302 2.03181 3.58181C2.11305 3.34061 2.24363 3.11896 2.41522 2.93098C2.58682 2.743 2.79567 2.59281 3.0285 2.48997C3.26132 2.38713 3.513 2.3339 3.76752 2.33366H6.51752C6.96238 2.32928 7.39366 2.48681 7.73097 2.7769C8.06827 3.06698 8.28859 3.46982 8.35085 3.91033C8.46692 4.79039 8.68218 5.65449 8.99252 6.48616C9.11585 6.81426 9.14254 7.17083 9.06943 7.51363C8.99632 7.85643 8.82648 8.17109 8.58002 8.42033L7.41585 9.58449C8.72078 11.8794 10.6209 13.7796 12.9159 15.0845L14.08 13.9203C14.3293 13.6739 14.6439 13.504 14.9867 13.4309C15.3295 13.3578 15.6861 13.3845 16.0142 13.5078C16.8459 13.8182 17.71 14.0334 18.59 14.1495C19.0353 14.2123 19.442 14.4366 19.7327 14.7797C20.0234 15.1228 20.1778 15.5608 20.1667 16.0103Z"
                                                    stroke="#5236FF" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_2011_91">
                                                    <rect width="22" height="22" fill="white"
                                                        transform="translate(0 0.5)" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="link">
                                        <a href="tel:21314234323543">+880 123 654 789 00</a> <br>
                                        <a href="tel:35234523452345">+001 6520 698 00</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom style1">
            <div class="container">
                <div class="footer-wrapper d-flex align-items-center justify-content-between">
                    <p class="wow fadeInLeft" data-wow-delay=".3s">
                        Copyright © Niotech All rights
                    </p>
                    <ul class="social-links" data-wow-delay=".5s">
                        <li> <a href="#"><i class="fa-brands fa-facebook-f"></i></a> </li>
                        <li> <a href="#"><i class="fa-brands fa-twitter"></i></a> </li>
                        <li> <a href="#"><i class="fa-brands fa-linkedin-in"></i></a> </li>
                        <li> <a href="#"><i class="fa-brands fa-instagram"></i></a> </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>



    <!-- All JS Plugins -->
<script src="{{ asset('assets/js/jquery-3.7.1.min.js') }}"></script>

<!-- Bootstrap Js -->
<script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>

<!-- Waypoints Js -->
<script src="{{ asset('assets/js/jquery.waypoints.js') }}"></script>

<!-- Counterup Js -->
<script src="{{ asset('assets/js/jquery.counterup.min.js') }}"></script>

<!-- Viewport Js -->
<script src="{{ asset('assets/js/viewport.jquery.js') }}"></script>

<!-- Tilt Js -->
<script src="{{ asset('assets/js/tilt.min.js') }}"></script>

<!-- Swiper Js -->
<script src="{{ asset('assets/js/swiper-bundle.min.js') }}"></script>

<!-- MeanMenu Js -->
<script src="{{ asset('assets/js/jquery.meanmenu.min.js') }}"></script>

<!-- Magnific Popup Js -->
<script src="{{ asset('assets/js/magnific-popup.min.js') }}"></script>

<!-- Wow Animation Js -->
<script src="{{ asset('assets/js/wow.min.js') }}"></script>

<!-- Nice Select Js -->
<script src="{{ asset('assets/js/nice-select.min.js') }}"></script>

<!-- Main Js -->
<script src="{{ asset('assets/js/main.js') }}"></script>
</body>

</html>