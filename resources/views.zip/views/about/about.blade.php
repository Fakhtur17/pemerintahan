<!DOCTYPE html>
<html lang="zxx">
<!--<< Header Area >>-->

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Gramentheme">
    <meta name="description" content="Niotech - App Landing HTML Template">
    <!-- ======== Page title ============ -->
    <title>Niotech - App Landing HTML Template</title>
    <!--<< Favcion >>-->
    <link rel="shortcut icon" href="{{ asset('assets/images/favicon.png') }}">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{ asset('assets/css/all.min.css') }}">
    <!-- Animate -->
    <link rel="stylesheet" href="{{ asset('assets/css/animate.css') }}">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="{{ asset('assets/css/magnific-popup.css') }}">
    <!-- MeanMenu -->
    <link rel="stylesheet" href="{{ asset('assets/css/meanmenu.css') }}">
    <!-- Swiper -->
    <link rel="stylesheet" href="{{ asset('assets/css/swiper-bundle.min.css') }}">
    <!-- Nice Select -->
    <link rel="stylesheet" href="{{ asset('assets/css/nice-select.css') }}">
    <!-- Main CSS -->
    <link rel="stylesheet" href="{{ asset('assets/css/main.css') }}">
</head>

<body>

    <!-- Preloader Start -->
    <div id="preloader" class="preloader">
        <div class="animation-preloader">
            <div class="spinner">
            </div>
            <div class="txt-loading">
                <span data-text-preloader="N" class="letters-loading">
                    N
                </span>
                <span data-text-preloader="E" class="letters-loading">
                    i
                </span>
                <span data-text-preloader="O" class="letters-loading">
                    O
                </span>
                <span data-text-preloader="T" class="letters-loading">
                    T
                </span>
                <span data-text-preloader="E" class="letters-loading">
                    E
                </span>
                <span data-text-preloader="C" class="letters-loading">
                    C
                </span>
                <span data-text-preloader="H" class="letters-loading">
                    H
                </span>
            </div>
            <p class="text-center">Loading</p>
        </div>
        <div class="loader">
            <div class="row">
                <div class="col-3 loader-section section-left">
                    <div class="bg"></div>
                </div>
                <div class="col-3 loader-section section-left">
                    <div class="bg"></div>
                </div>
                <div class="col-3 loader-section section-right">
                    <div class="bg"></div>
                </div>
                <div class="col-3 loader-section section-right">
                    <div class="bg"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mouse Cursor Start -->
    <div class="mouse-cursor cursor-outer"></div>
    <div class="mouse-cursor cursor-inner"></div>

    <!-- Back To Top Start -->
    <button id="back-top" class="back-to-top">
        <i class="fa-solid fa-chevron-up"></i>
    </button>

    <!-- Offcanvas Area Start -->
    <div class="fix-area">
        <div class="offcanvas__info">
            <div class="offcanvas__wrapper">
                <div class="offcanvas__content">
                    <div class="offcanvas__top mb-5 d-flex justify-content-between align-items-center">
                        <div class="offcanvas__logo">
                            <a href="{{ route('home') }}">
                                <img src="assets/images/logo/logo2.svg" alt="logo-img">
                            </a>
                        </div>
                        <div class="offcanvas__close">
                            <button>
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <p class="text d-none d-xl-block">
                        Nullam dignissim, ante scelerisque the is euismod fermentum odio sem semper the is erat, a
                        feugiat leo urna eget eros. Duis Aenean a imperdiet risus.
                    </p>
                    <div class="mobile-menu fix mb-3"></div>
                    <div class="offcanvas__contact">
                        <h4>Contact Info</h4>
                        <ul>
                            <li class="d-flex align-items-center">
                                <div class="offcanvas__contact-icon">
                                    <i class="fal fa-map-marker-alt"></i>
                                </div>
                                <div class="offcanvas__contact-text">
                                    <a target="_blank" href="#">Main Street, Melbourne, Australia</a>
                                </div>
                            </li>
                            <li class="d-flex align-items-center">
                                <div class="offcanvas__contact-icon mr-15">
                                    <i class="fal fa-envelope"></i>
                                </div>
                                <div class="offcanvas__contact-text">
                                    <a href="mailto:info@example.com"><span
                                            class="mailto:info@example.com">info@example.com</span></a>
                                </div>
                            </li>
                            <li class="d-flex align-items-center">
                                <div class="offcanvas__contact-icon mr-15">
                                    <i class="fal fa-clock"></i>
                                </div>
                                <div class="offcanvas__contact-text">
                                    <a target="_blank" href="#">Mod-friday, 09am -05pm</a>
                                </div>
                            </li>
                            <li class="d-flex align-items-center">
                                <div class="offcanvas__contact-icon mr-15">
                                    <i class="far fa-phone"></i>
                                </div>
                                <div class="offcanvas__contact-text">
                                    <a href="tel:+11002345909">+11002345909</a>
                                </div>
                            </li>
                        </ul>
                        <div class="header-button mt-4">
                            <a href="contact.html" class="theme-btn text-center">
                                <span>Get A Quote<i class="fa-solid fa-arrow-right-long"></i></span>
                            </a>
                        </div>
                        <div class="social-icon d-flex align-items-center">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-youtube"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="offcanvas__overlay"></div>

    <!-- Header Section Start -->
     <!-- Header Section Start -->
    <header class="header-section-1">
        <div id="header-sticky" class="header-1">
            <div class="container">
                <div class="mega-menu-wrapper">
                    <div class="header-main">
                        <div class="header-left">
                            <div class="logo">
                                <a href="{{ route('home') }}" class="header-logo">
                                    <img src="assets/images/logo/logo.svg" alt="logo-img">
                                </a>
                            </div>
                        </div>
                        <div class="header-middle">
                            <div class="mean__menu-wrapper">
                                <div class="main-menu">
                                    <nav id="mobile-menu">
                                        <ul>
                                            <li class="has-dropdown active menu-thumb">
                                                <a href="#">
                                                    Home
                                                    <i class="fas fa-angle-down"></i>
                                                </a>
                                                <ul class="submenu has-homemenu">
                                                    <li>
                                                        <div class="homemenu-items">
                                                            <div class="homemenu">
                                                                <div class="homemenu-thumb">
                                                                    <img src="assets/images/header/home-1.png"
                                                                        alt="img">
                                                                    <div class="demo-button">
                                                                        <a class="theme-btn" href="{{ route('home') }}">
                                                                            Multi Page
                                                                        </a>
                                                                        <a class="theme-btn" href="{{ route('one-page') }}">
                                                                            One Page
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="homemenu-content text-center">
                                                                    <h4 class="homemenu-title">
                                                                        Home 01
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="homemenu">
                                                                <div class="homemenu-thumb mb-15">
                                                                    <img src="assets/images/header/home-2.png"
                                                                        alt="img">
                                                                    <div class="demo-button">
                                                                        <a class="theme-btn" href="{{ route('home2') }}">
                                                                            Multi Page
                                                                        </a>
                                                                        <a class="theme-btn" href="{{ route('two-page') }}">
                                                                            One Page
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="homemenu-content text-center">
                                                                    <h4 class="homemenu-title">
                                                                        Home 02
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                            <div class="homemenu">
                                                                <div class="homemenu-thumb mb-15">
                                                                    <img src="assets/images/header/home-3.png"
                                                                        alt="img">
                                                                    <div class="demo-button">
                                                                        <a class="theme-btn" href="{{ route('home3') }}">
                                                                            Multi Page
                                                                        </a>
                                                                        <a class="theme-btn" href="{{ route('three-page') }}">
                                                                            One Page
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="homemenu-content text-center">
                                                                    <h4 class="homemenu-title">
                                                                        Home 03
                                                                    </h4>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="has-dropdown active d-xl-none">
                                                <a href="{{ route('home') }}" class="border-none">
                                                    Home
                                                    <i class="fa-regular fa-plus"></i>
                                                </a>
                                                <ul class="submenu">
                                                    <li><a href="{{ route('home') }}">Home 01</a></li>
                                                    <li><a href="{{ route('home2') }}">Home 02</a></li>
                                                    <li><a href="{{ route('home3') }}">Home 03</a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="#about">About Us</a>
                                            </li>
                                            <li>
                                                <a href="#features"> Features </a>
                                            </li>
                                            <li>
                                                <a href="#pricing"> Pricing </a>
                                            </li>
                                            <li>
                                                <a href="#blog"> Blog </a>
                                            </li>
                                            <li>
                                                <a href="#app">Our App</a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                        <div class="header-right d-flex justify-content-end align-items-center">
                            <a href="#0" class="search-trigger search-icon"><i class="fal fa-search"></i></a>

                            <div class="header-button ms-4">
                                <a href="contact.html" class="theme-btn">
                                    <span>
                                        Get Started
                                        <i class="fa-solid fa-arrow-right-long"></i>
                                    </span>
                                </a>
                            </div>
                            <div class="header__hamburger d-block d-xl-none my-auto">
                                <div class="sidebar__toggle">
                                    <i class="fas fa-bars"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Search Area Start -->
    <div class="search-wrap">
        <div class="search-inner">
            <i class="fas fa-times search-close" id="search-close"></i>
            <div class="search-cell">
                <form method="get">
                    <div class="search-field-holder">
                        <input type="search" class="main-search-input" placeholder="Search...">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Breadcumb Section S T A R T -->
    <div class="breadcumb-section fix">
        <div class="breadcumb-container-wrapper" data-bg-src="assets/images/bg/breadcumgBg.png">
            <div class="container">
                <div class="shape1"><img src="assets/images/shape/breadCumbShape1_1.png" alt="shape"></div>
                <div class="shape2"><img src="assets/images/shape/breadCumbShape1_2.png" alt="shape"></div>
                <div class="breadcumb-wrapper">
                    <div class="page-heading">
                        <h1>About Us</h1>
                        <div class="links">
                            <a href="{{ route('home') }}">Home<span class="slash">/</span></a>About Us
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- About Us Section S T A R T -->
    <section class="about-section section-padding fix">
        <div class="about-container-wrapper style1">
            <div class="container">
                <div class="about-wrapper style1">
                    <div class="row gy-5 gx-60">
                        <div class="col-xl-6">
                            <div class="about-thumb">
                                <div class="bg"></div>
                                <div class="thumbShape1 d-none d-xxl-block cir36"><img
                                        src="assets/images/shape/aboutThumbShape1_1.png" alt="shape"></div>
                                <div class="thumbShape2 d-none d-xxl-block cir36"><img
                                        src="assets/images/shape/aboutThumbShape1_2.png" alt="shape"></div>
                                <div class="thumbShape3 d-none d-xxl-block cir36 float-bob-y"><img
                                        src="assets/images/shape/aboutThumbShape1_3.png" alt="shape"></div>
                                <div class="thumbShape4 d-none d-xxl-block cir36"><img
                                        src="assets/images/shape/aboutThumbShape1_4.png" alt="shape"></div>
                                <div class="main-thumb">
                                    <img src="assets/images/about/aboutThumb1_1.png" alt="thumb">
                                </div>
                                <div class="absolute-thumb float-bob-x">
                                    <img src="assets/images/about/aboutThumb1_2.png" alt="thumb">
                                </div>

                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="about-content">
                                <div class="section-title">
                                    <div class="subtitle wow fadeInUp" data-wow-delay=".2s">
                                        About Our App <img src="assets/images/icon/fireIcon.svg" alt="icon">
                                    </div>
                                    <h2 class="title wow fadeInUp" data-wow-delay=".4s">Simple Reports & Analytics
                                        Backdown As it</h2>
                                    <p class="section-desc wow fadeInUp" data-wow-delay=".6s">There are many variations
                                        of passages of Lorem Ipsum
                                        available, but the majority have suffered alteration in some form, by injected
                                        humour, or randomised words which don't look even slightly believable. If you
                                        are going to use</p>
                                </div>
                                <ul class="checklist style1 wow fadeInUp" data-wow-delay=".2s">
                                    <li><img src="assets/images/icon/checkmarkIcon.svg" alt="icon"> With our
                                        Technological and Marketing Solutions.</li>
                                    <li><img src="assets/images/icon/checkmarkIcon.svg" alt="icon"> We are trusted all
                                        over the world. </li>
                                    <li><img src="assets/images/icon/checkmarkIcon.svg" alt="icon"> Start Your 14 Days
                                        Free Trials Today! </li>
                                </ul>
                                <a class="theme-btn wow fadeInUp" data-wow-delay=".2s" href="{{ route('about') }}">Discover More
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"
                                        fill="none">
                                        <g clip-path="url(#clip0_18_41)">
                                            <path
                                                d="M11.6118 3.61182L10.8991 4.32454L14.0706 7.49603H0V8.50398H14.0706L10.8991 11.6754L11.6118 12.3882L16 7.99997L11.6118 3.61182Z"
                                                fill="white" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_18_41">
                                                <rect width="16" height="16" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Choose Us Section S T A R T -->
    <section class="wcu-section">
        <div class="wcu-container-wrapper style2">
            <div class="container">
                <div class="wcu-wrapper style2  section-padding fix">
                    <div class="container">
                        <div class="row gy-5 gx-60 d-flex align-items-center">
                            <div class="col-xl-6">
                                <div class="wcu-thumb">
                                    <div class="main-thumb img-custom-anim-right wow fadeInUp" data-wow-delay=".4s">
                                        <img src="assets/images/wcu/wcuThumb2_1.png" alt="thumb">
                                    </div>
                                    <div class="thumb2 float-bob-y"><img src="assets/images/wcu/wcuThumb2_2.png"
                                            alt="thumb"></div>
                                    <div class="thumb3 float-bob-x"><img src="assets/images/wcu/wcuThumb2_3.png"
                                            alt="thumb"></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="wcu-content">
                                    <div class="section-title">
                                        <div class="subtitle wow fadeInUp" data-wow-delay=".2s">
                                            Customizations & Analysis <img src="assets/images/icon/fireIcon.svg"
                                                alt="icon">
                                        </div>
                                        <h2 class="title wow fadeInUp" data-wow-delay=".4s">Manage your Team’s Easily
                                            Communication.</h2>
                                        <p class="text1 wow fadeInUp" data-wow-delay=".6s">There are many variations of
                                            passages of Lorem Ipsum available, but the majority have suffered alteration
                                            in some form, by injected humour, or randomised words which don't look even
                                        </p>
                                    </div>
                                    <div class="fancy-box style3 mb-20 wow fadeInUp" data-wow-delay=".4s">
                                        <div class="icon">
                                            <img src="assets/images/icon/wcuIcon2_1.svg" alt="icon">
                                        </div>
                                        <div class="content">
                                            <h4>Easy Collaboration</h4>
                                            <p class="text">There are many variations of passages of Lorem Ipsum
                                                available, but the majority have</p>
                                        </div>
                                    </div>
                                    <div class="fancy-box style3 wow fadeInUp" data-wow-delay=".6s">
                                        <div class="icon">
                                            <img src="assets/images/icon/wcuIcon2_2.svg" alt="icon">
                                        </div>
                                        <div class="content">
                                            <h4>Innovative Solutions</h4>
                                            <p class="text">There are many variations of passages of Lorem Ipsum
                                                available, but the majority have</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Work Process Section S T A R T -->
    <section class="work-process-section section-padding fix">
        <div class="work-process-container-wrapper style1">
            <div class="container">
                <div class="section-title text-center mxw-565 mx-auto">
                    <div class="subtitle wow fadeInUp" data-wow-delay=".2s">
                        How It Work <img src="assets/images/icon/fireIcon.svg" alt="icon">
                    </div>
                    <h2 class="title wow fadeInUp" data-wow-delay=".4s">Make Your Device Manage Everything For You!</h2>
                </div>
                <div class="work-process-wrapper style1">
                    <div class="shape"><img src="assets/images/shape/workProcessShape1_1.png" alt="shape"></div>
                    <div class="row">
                        <div class="col-xl-4">
                            <div class="work-process-box style1 wow fadeInUp" data-wow-delay=".2s">
                                <div class="step">STEP - 01</div>
                                <div class="title">Download App</div>
                                <div class="text">There are many variations of passages of Lorem</div>
                            </div>
                        </div>
                        <div class="col-xl-4">
                            <div class="work-process-box style1 child2 wow fadeInUp" data-wow-delay=".4s">
                                <div class="step">STEP - 02</div>
                                <div class="title">Create account</div>
                                <div class="text">There are many variations of passages of Lorem</div>
                            </div>
                        </div>
                        <div class="col-xl-4">
                            <div class="work-process-box style1 wow fadeInUp" data-wow-delay=".6s">
                                <div class="step">STEP - 03</div>
                                <div class="title">Install App, & Enjoy</div>
                                <div class="text">There are many variations of passages of Lorem</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Choose Us Section S T A R T -->
    <section class="wcu-section section-padding pt-0 fix">
        <div class="wcu-container-wrapper style3">
            <div class="container">
                <div class="wcu-wrapper style3">
                    <div class="row gy-5 gx-60">
                        <div class="col-xl-6">
                            <div class="wcu-content">
                                <div class="section-title">
                                    <div class="subtitle wow fadeInUp" data-wow-delay=".2s">
                                        Customizations & Analysis <img src="assets/images/icon/fireIcon.svg" alt="icon">
                                    </div>
                                    <h2 class="title wow fadeInUp" data-wow-delay=".4s">Manage your Traffic Growth
                                        Easily</h2>
                                    <p class="text1 wow fadeInUp" data-wow-delay=".6s">There are many variations of
                                        passages of Lorem Ipsum available, but the majority have suffered alteration in
                                        some form, by injected humour, or randomised words which don't look even</p>
                                    <p class="text2 wow fadeInUp" data-wow-delay=".8s">There are many variations of
                                        passages of Lorem Ipsum available, but the majority have suffered alteration in
                                        some form,</p>
                                </div>
                                <a class="theme-btn rounded-5 wow fadeInUp" data-wow-delay=".4s" href="{{ route('about') }}">View
                                    All Project
                                    <svg class="ms-2" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                        viewBox="0 0 16 16" fill="none">
                                        <g clip-path="url(#clip0_190_64)">
                                            <path
                                                d="M11.6118 3.61182L10.8991 4.32454L14.0706 7.49603H0V8.50398H14.0706L10.8991 11.6754L11.6118 12.3882L16 7.99997L11.6118 3.61182Z"
                                                fill="white" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_190_64">
                                                <rect width="16" height="16" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </a>
                                <div class="counter-box-wrapper style3">
                                    <div class="counter-box style3 wow fadeInUp" data-wow-delay=".2s">
                                        <div class="counter">
                                            <span class="counter-nubmer">56</span> <span>k+</span>
                                        </div>
                                        <p class="text">Comparers</p>
                                    </div>
                                    <div class="counter-box style3 wow fadeInUp" data-wow-delay=".4s">
                                        <div class="counter">
                                            <span class="counter-nubmer">126</span> <span>k+</span>
                                        </div>
                                        <p class="text">Use People</p>
                                    </div>
                                    <div class="counter-box style3 wow fadeInUp" data-wow-delay=".6s">
                                        <div class="counter">
                                            <span class="counter-nubmer">1.2</span> <span>M+</span>
                                        </div>
                                        <p class="text">Download It</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="wcu-thumb">
                                <div class="main-thumb img-custom-anim-left wow fadeInUp" data-wow-delay=".4s">
                                    <img src="assets/images/wcu/wcuThumb3_1.png" alt="thumb">
                                </div>
                                <div class="thumb2">
                                    <img src="assets/images/wcu/wcuThumb3_2.png" alt="thumb">
                                </div>
                                <div class="thumb-box wow fadeInUp" data-wow-delay=".4s">
                                    <h5>Traffic Growth</h5>
                                    <p class="text">Total traffic growth of 45%</p>
                                    <div class="shape-box">
                                        <img src="assets/images/shape/wcuThumbShape3_1.png" alt="shape">
                                        <div class="shape-content">
                                            <h6>Transaction</h6>
                                            <h3>86%</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Testimonial Section S T A R T -->
    <section class="testimonial-section section-padding pt-0 fix">
        <div class="container">
            <div class="testimonial-wrapper style3">
                <div class="section-title-wrapper style3">
                    <div class="row d-flex align-items-center">
                        <div class="col-xl-6">
                            <div class="section-title">
                                <div class="subtitle">
                                    Testimonial <img src="assets/images/icon/fireIcon.svg" alt="icon">
                                </div>
                                <h2 class="title">What our clients say?</h2>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="slider-arrow-button style2 text-end wow fadeInUp" data-wow-delay=".9s">
                                <button data-slider-prev="#testimonialSliderThree" class="slider-arrow arrowPrev"><i
                                        class="fa-sharp fa-solid fa-chevron-left"></i></button>
                                <button data-slider-next="#testimonialSliderThree" class="slider-arrow arrowNext"><i
                                        class="fa-sharp fa-solid fa-chevron-right"></i></button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="slider-area testimonialSliderThree">
                    <div class="swiper gt-slider" id="testimonialSliderThree"
                        data-slider-options='{"loop": true,"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":1,"centeredSlides":true},"768":{"slidesPerView":1},"992":{"slidesPerView":2},"1200":{"slidesPerView":3}}}'>
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="testimonial-card style2">
                                    <div class="testimonial-header">
                                        <div class="profile-thumb">
                                            <img src="assets/images/testimoial/testimonialProfileThumb1_1.jpg"
                                                alt="thumb">
                                        </div>
                                        <div class="content">
                                            <h5>Jacob Jones</h5>
                                            <p class="text">Team Leader</p>
                                        </div>
                                    </div>
                                    <div class="testimonial-body">
                                        <ul class="star-wrapper style1">
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                        </ul>
                                        <p class="desc">There are many variations of passages of Lorem Ipsum
                                            available,a but
                                            chiropractor like majority have a suffered alteration in some form,
                                            by injected humour,</p>
                                    </div>
                                    <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg" alt="icon">
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonial-card style2">
                                    <div class="testimonial-header">
                                        <div class="profile-thumb">
                                            <img src="assets/images/testimoial/testimonialProfileThumb1_2.jpg"
                                                alt="thumb">
                                        </div>
                                        <div class="content">
                                            <h5>Selim Box</h5>
                                            <p class="text">Team Leader</p>
                                        </div>
                                    </div>
                                    <div class="testimonial-body">
                                        <ul class="star-wrapper style1">
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                        </ul>
                                        <p class="desc">There are many variations of passages of Lorem Ipsum
                                            available,a but
                                            chiropractor like majority have a suffered alteration in some form,
                                            by injected humour,</p>
                                    </div>
                                    <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg" alt="icon">
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonial-card style2">
                                    <div class="testimonial-header">
                                        <div class="profile-thumb">
                                            <img src="assets/images/testimoial/testimonialProfileThumb1_3.jpg"
                                                alt="thumb">
                                        </div>
                                        <div class="content">
                                            <h5>Masirul Islam</h5>
                                            <p class="text">Team Leader</p>
                                        </div>
                                    </div>
                                    <div class="testimonial-body">
                                        <ul class="star-wrapper style1">
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                        </ul>
                                        <p class="desc">There are many variations of passages of Lorem Ipsum
                                            available,a but
                                            chiropractor like majority have a suffered alteration in some form,
                                            by injected humour,</p>
                                    </div>
                                    <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg" alt="icon">
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonial-card style2">
                                    <div class="testimonial-header">
                                        <div class="profile-thumb">
                                            <img src="assets/images/testimoial/testimonialProfileThumb1_1.jpg"
                                                alt="thumb">
                                        </div>
                                        <div class="content">
                                            <h5>Jacob Jones</h5>
                                            <p class="text">Team Leader</p>
                                        </div>
                                    </div>
                                    <div class="testimonial-body">
                                        <ul class="star-wrapper style1">
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                        </ul>
                                        <p class="desc">There are many variations of passages of Lorem Ipsum
                                            available,a but
                                            chiropractor like majority have a suffered alteration in some form,
                                            by injected humour,</p>
                                    </div>
                                    <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg" alt="icon">
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonial-card style2">
                                    <div class="testimonial-header">
                                        <div class="profile-thumb">
                                            <img src="assets/images/testimoial/testimonialProfileThumb1_1.jpg"
                                                alt="thumb">
                                        </div>
                                        <div class="content">
                                            <h5>Jacob Jones</h5>
                                            <p class="text">Team Leader</p>
                                        </div>
                                    </div>
                                    <div class="testimonial-body">
                                        <ul class="star-wrapper style1">
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                        </ul>
                                        <p class="desc">There are many variations of passages of Lorem Ipsum
                                            available,a but
                                            chiropractor like majority have a suffered alteration in some form,
                                            by injected humour,</p>
                                    </div>
                                    <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg" alt="icon">
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonial-card style2">
                                    <div class="testimonial-header">
                                        <div class="profile-thumb">
                                            <img src="assets/images/testimoial/testimonialProfileThumb1_1.jpg"
                                                alt="thumb">
                                        </div>
                                        <div class="content">
                                            <h5>Jacob Jones</h5>
                                            <p class="text">Team Leader</p>
                                        </div>
                                    </div>
                                    <div class="testimonial-body">
                                        <ul class="star-wrapper style1">
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                            <li><img src="assets/images/icon/starIcon1_1.svg" alt="icon"></li>
                                        </ul>
                                        <p class="desc">There are many variations of passages of Lorem Ipsum
                                            available,a but
                                            chiropractor like majority have a suffered alteration in some form,
                                            by injected humour,</p>
                                    </div>
                                    <div class="quote-icon"><img src="assets/images/icon/quoteIcon.svg" alt="icon">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- Footer Section    S T A R T -->
    <footer class="footer-section position-relative">
        <div class="footer-widgets-wrapper style1 fix">
            <div class="shape1"><img src="assets/images/shape/footerShape1_1.png" alt="shape"></div>
            <div class="shape2"><img src="assets/images/shape/footerShape1_2.png" alt="shape"></div>
            <div class="shape3"><img src="assets/images/shape/footerShape1_3.png" alt="shape"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay=".2s">
                        <div class="single-footer-widget">
                            <div class="widget-head">
                                <a href="{{ route('home') }}">
                                    <img src="assets/images/logo/logo.svg" alt="logo-img">
                                </a>
                            </div>
                            <div class="footer-content">
                                <p>
                                    It is a long established fact that from will be distracted by the readable from when
                                    looking.
                                </p>
                                <div class="store-links">
                                    <div class="apple">
                                        <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="19" height="17"
                                                viewBox="0 0 19 17" fill="none">
                                                <path
                                                    d="M13.9741 0.148438C11.9982 0.148438 11.1631 1.09311 9.78702 1.09311C8.37612 1.09311 7.29994 0.155311 5.58766 0.155311C3.91164 0.155311 2.12437 1.1805 0.989386 2.92696C-0.604303 5.38978 -0.333787 10.0282 2.24738 13.9797C3.17066 15.3942 4.40366 16.9806 6.02087 16.9978H6.05028C7.45578 16.9978 7.87332 16.0757 9.8076 16.0649H9.837C11.7424 16.0649 12.1246 16.9924 13.5242 16.9924H13.5536C15.1709 16.9752 16.47 15.2175 17.3933 13.8083C18.0578 12.7949 18.3048 12.2863 18.8145 11.1398C15.0807 9.71985 14.4809 4.41664 18.1735 2.38344C17.0463 0.969377 15.4624 0.150401 13.9692 0.150401L13.9741 0.148438Z"
                                                    fill="white" />
                                            </svg> App Store</a>
                                    </div>
                                    <div class="play">
                                        <a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="26" height="17"
                                                viewBox="0 0 26 17" fill="none">
                                                <path
                                                    d="M18.8732 5.50779L20.9775 1.64735C21.0339 1.54372 21.0493 1.42066 21.0204 1.30505C20.9914 1.18943 20.9204 1.09065 20.8229 1.03026C20.7748 1.00032 20.7215 0.980802 20.6661 0.97283C20.6108 0.964858 20.5545 0.968593 20.5005 0.983821C20.4466 0.999048 20.396 1.02546 20.3517 1.06154C20.3075 1.09761 20.2704 1.14263 20.2427 1.19398L18.1122 5.10427C16.4855 4.31717 14.6547 3.87902 12.6857 3.87902C10.7167 3.87902 8.88588 4.3177 7.25923 5.10427L5.12868 1.19398C5.07191 1.09044 4.97863 1.01502 4.86936 0.984319C4.76008 0.953616 4.64377 0.970142 4.546 1.03026C4.44823 1.09038 4.37702 1.18917 4.34803 1.3049C4.31904 1.42062 4.33464 1.54381 4.39141 1.64735L6.49075 5.50779C2.86386 7.58782 0.405796 11.4776 0 16.0313H25.3684C24.9626 11.4776 22.5046 7.58782 18.8732 5.50779ZM6.85988 12.2584C6.64958 12.2584 6.444 12.1924 6.26914 12.0687C6.09429 11.9449 5.958 11.7691 5.87752 11.5633C5.79705 11.3575 5.77599 11.1311 5.81702 10.9127C5.85804 10.6942 5.95931 10.4936 6.10802 10.3361C6.25672 10.1786 6.44618 10.0714 6.65244 10.0279C6.8587 9.98449 7.07249 10.0068 7.26678 10.092C7.46108 10.1772 7.62714 10.3216 7.74398 10.5068C7.86081 10.6919 7.92317 10.9097 7.92317 11.1324C7.92304 11.431 7.81097 11.7173 7.6116 11.9285C7.41222 12.1396 7.14184 12.2583 6.85988 12.2584ZM18.5036 12.2584C18.2935 12.2575 18.0883 12.1907 17.9141 12.0664C17.7398 11.9421 17.6042 11.7659 17.5244 11.56C17.4446 11.3542 17.4242 11.1279 17.4657 10.9098C17.5073 10.6917 17.6089 10.4915 17.7578 10.3345C17.9066 10.1775 18.0961 10.0707 18.3022 10.0276C18.5084 9.98453 18.7219 10.0071 18.916 10.0925C19.11 10.1778 19.2758 10.3222 19.3924 10.5073C19.5091 10.6923 19.5713 10.9099 19.5713 11.1324C19.5713 11.2804 19.5436 11.4271 19.49 11.5638C19.4364 11.7006 19.3579 11.8248 19.2589 11.9294C19.1599 12.034 19.0424 12.1169 18.9132 12.1733C18.7839 12.2298 18.6454 12.2587 18.5056 12.2584H18.5036Z"
                                                    fill="#242331" />
                                            </svg> Play Store</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-4 col-md-6 ps-lg-5 wow fadeInUp" data-wow-delay=".4s">
                        <div class="single-footer-widget">
                            <div class="widget-head">
                                <h3> Pages </h3>
                            </div>
                            <ul class="list-area">
                                <li>
                                    <a href="{{ route('home') }}">
                                        Home
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ route('about') }}">
                                        About Us
                                    </a>
                                </li>
                                <li>
                                    <a href="project1.html">
                                        Integrations
                                    </a>
                                </li>
                                <li>
                                    <a href="services.html">
                                        Features
                                    </a>
                                </li>
                                <li>
                                    <a href="pricing.html">
                                        Pricing
                                    </a>
                                </li>
                                <li>
                                    <a href="contact.html">
                                        Contact Us
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay=".8s">
                        <div class="single-footer-widget">
                            <div class="widget-head">
                                <h3> Utility Pages </h3>
                            </div>
                            <ul class="list-area">
                                <li>
                                    <a href="project1.html">
                                        Project
                                    </a>
                                </li>
                                <li>
                                    <a href="blog.html">
                                        Blog
                                    </a>
                                </li>
                                <li>
                                    <a href="contact.html">
                                        Contact
                                    </a>
                                </li>
                                <li>
                                    <a href="pricing.html">
                                        Pricing
                                    </a>
                                </li>
                                <li>
                                    <a href="project-details.html">
                                        Project details
                                    </a>
                                </li>
                                <li>
                                    <a href="team.html">
                                        Our Team
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="single-footer-widget">
                            <div class="contact-box">
                                <div class="subtitle">Address</div>
                                <div class="widget-head">Ready to get started?</div>
                                <div class="text">It is a long established fact that a reader will be distracted layout.
                                </div>
                                <div class="info">
                                    <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="23"
                                            viewBox="0 0 22 23" fill="none">
                                            <path
                                                d="M3.66671 4.16699H18.3334C19.3417 4.16699 20.1667 4.99199 20.1667 6.00033V17.0003C20.1667 18.0087 19.3417 18.8337 18.3334 18.8337H3.66671C2.65837 18.8337 1.83337 18.0087 1.83337 17.0003V6.00033C1.83337 4.99199 2.65837 4.16699 3.66671 4.16699Z"
                                                stroke="#5236FF" stroke-width="2" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path d="M20.1667 6L11 12.4167L1.83337 6" stroke="#5236FF" stroke-width="2"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    <div class="link">
                                        <a href="mailto:contact.tech@gmail.com">contact.tech@gmail.com</a> <br>
                                        <a href="mailto:info@Niotech.com">info@Niotech.com</a>
                                    </div>
                                </div>
                                <div class="info">
                                    <div class="icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="23"
                                            viewBox="0 0 22 23" fill="none">
                                            <g clip-path="url(#clip0_2011_91)">
                                                <path
                                                    d="M13.7959 5.08366C14.6912 5.25834 15.514 5.69623 16.1591 6.34127C16.8041 6.9863 17.242 7.80915 17.4167 8.70449L13.7959 5.08366ZM13.7959 1.41699C15.656 1.62364 17.3906 2.45665 18.7149 3.77925C20.0392 5.10185 20.8744 6.83542 21.0834 8.69533L13.7959 1.41699ZM20.1667 16.0103V18.7603C20.1677 19.0156 20.1154 19.2683 20.0132 19.5022C19.9109 19.7361 19.7609 19.9461 19.5728 20.1187C19.3846 20.2913 19.1625 20.4227 18.9207 20.5045C18.6789 20.5863 18.4226 20.6166 18.1684 20.5937C15.3476 20.2872 12.6381 19.3233 10.2575 17.7795C8.0427 16.3721 6.16491 14.4943 4.75752 12.2795C3.20833 9.8881 2.24424 7.1654 1.94335 4.33199C1.92045 4.0785 1.95057 3.82302 2.03181 3.58181C2.11305 3.34061 2.24363 3.11896 2.41522 2.93098C2.58682 2.743 2.79567 2.59281 3.0285 2.48997C3.26132 2.38713 3.513 2.3339 3.76752 2.33366H6.51752C6.96238 2.32928 7.39366 2.48681 7.73097 2.7769C8.06827 3.06698 8.28859 3.46982 8.35085 3.91033C8.46692 4.79039 8.68218 5.65449 8.99252 6.48616C9.11585 6.81426 9.14254 7.17083 9.06943 7.51363C8.99632 7.85643 8.82648 8.17109 8.58002 8.42033L7.41585 9.58449C8.72078 11.8794 10.6209 13.7796 12.9159 15.0845L14.08 13.9203C14.3293 13.6739 14.6439 13.504 14.9867 13.4309C15.3295 13.3578 15.6861 13.3845 16.0142 13.5078C16.8459 13.8182 17.71 14.0334 18.59 14.1495C19.0353 14.2123 19.442 14.4366 19.7327 14.7797C20.0234 15.1228 20.1778 15.5608 20.1667 16.0103Z"
                                                    stroke="#5236FF" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_2011_91">
                                                    <rect width="22" height="22" fill="white"
                                                        transform="translate(0 0.5)" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="link">
                                        <a href="tel:21314234323543">+880 123 654 789 00</a> <br>
                                        <a href="tel:35234523452345">+001 6520 698 00</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom style1">
            <div class="container">
                <div class="footer-wrapper d-flex align-items-center justify-content-between">
                    <p class="wow fadeInLeft" data-wow-delay=".3s">
                        Copyright © Niotech All rights
                    </p>
                    <ul class="social-links" data-wow-delay=".5s">
                        <li> <a href="#"><i class="fa-brands fa-facebook-f"></i></a> </li>
                        <li> <a href="#"><i class="fa-brands fa-twitter"></i></a> </li>
                        <li> <a href="#"><i class="fa-brands fa-linkedin-in"></i></a> </li>
                        <li> <a href="#"><i class="fa-brands fa-instagram"></i></a> </li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>




    <script src="{{ asset('assets/js/jquery-3.7.1.min.js') }}"></script>
    <!-- Bootstrap Js -->
    <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
    <!-- Waypoints Js -->
    <script src="{{ asset('assets/js/jquery.waypoints.js') }}"></script>
    <!-- Counterup Js -->
    <script src="{{ asset('assets/js/jquery.counterup.min.js') }}"></script>
    <!-- Viewport Js -->
    <script src="{{ asset('assets/js/viewport.jquery.js') }}"></script>
    <!-- Tilt Js -->
    <script src="{{ asset('assets/js/tilt.min.js') }}"></script>
    <!-- Swiper Js -->
    <script src="{{ asset('assets/js/swiper-bundle.min.js') }}"></script>
    <!-- MeanMenu Js -->
    <script src="{{ asset('assets/js/jquery.meanmenu.min.js') }}"></script>
    <!-- Magnific Popup Js -->
    <script src="{{ asset('assets/js/magnific-popup.min.js') }}"></script>
    <!-- Wow Animation Js -->
    <script src="{{ asset('assets/js/wow.min.js') }}"></script>
    <!-- Nice Select Js -->
    <script src="{{ asset('assets/js/nice-select.min.js') }}"></script>
    <!-- Main Js -->
    <script src="{{ asset('assets/js/main.js') }}"></script>
</body>

</html>